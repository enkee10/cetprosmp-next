--
-- PostgreSQL database dump
--

\restrict 1imUoEKVVdPZUyrLGZlkcGZ4PhPtKysXyK6XEvsNeY0yaQ4iW1uQa98Z2e60iNi

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acciones (
    id integer NOT NULL,
    descripcion text
);


--
-- Name: acciones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.acciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: acciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.acciones_id_seq OWNED BY public.acciones.id;


--
-- Name: act_economicas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_economicas (
    id integer NOT NULL,
    descripcion text,
    especialidad_id integer,
    familia_id integer,
    titulo text,
    imagen_portada_url text
);


--
-- Name: act_economicas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.act_economicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: act_economicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.act_economicas_id_seq OWNED BY public.act_economicas.id;


--
-- Name: actividades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.actividades (
    id integer NOT NULL,
    aprendizaje_id integer NOT NULL,
    eje_transversal_id integer,
    valor_institucional_id integer,
    ambiente text,
    bibliografia text,
    descripcion text,
    duracion integer,
    fecha timestamp with time zone,
    nombre text,
    proposito text
);


--
-- Name: actividades_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.actividades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: actividades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.actividades_id_seq OWNED BY public.actividades.id;


--
-- Name: anios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.anios (
    id integer NOT NULL,
    nombre text,
    titulo text
);


--
-- Name: anios_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.anios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: anios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.anios_id_seq OWNED BY public.anios.id;


--
-- Name: aprendizajes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aprendizajes (
    id integer NOT NULL,
    indicador_capacidad_id integer NOT NULL,
    descripcion text,
    sigla text
);


--
-- Name: aprendizajes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aprendizajes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aprendizajes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aprendizajes_id_seq OWNED BY public.aprendizajes.id;


--
-- Name: asistencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asistencias (
    id integer NOT NULL,
    evento_ocurrencia_id integer NOT NULL,
    matricula_id integer NOT NULL,
    registrado_por_id integer,
    estado_asistencia text,
    fecha_actualizacion timestamp with time zone,
    fecha_creacion timestamp with time zone,
    observacion text,
    registrado_at timestamp with time zone
);


--
-- Name: asistencias_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.asistencias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: asistencias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.asistencias_id_seq OWNED BY public.asistencias.id;


--
-- Name: aspectos_evaluacion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aspectos_evaluacion (
    id integer NOT NULL,
    evaluacion_id integer NOT NULL,
    descripcion text
);


--
-- Name: aspectos_evaluacion_estudiantes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.aspectos_evaluacion_estudiantes (
    id integer NOT NULL,
    aspecto_evaluacion_id integer NOT NULL,
    evaluacion_estudiante_id integer CONSTRAINT aspectos_evaluacion_estudiant_evaluacion_estudiante_id_not_null NOT NULL,
    puntaje double precision
);


--
-- Name: aspectos_evaluacion_estudiantes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aspectos_evaluacion_estudiantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aspectos_evaluacion_estudiantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aspectos_evaluacion_estudiantes_id_seq OWNED BY public.aspectos_evaluacion_estudiantes.id;


--
-- Name: aspectos_evaluacion_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.aspectos_evaluacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: aspectos_evaluacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.aspectos_evaluacion_id_seq OWNED BY public.aspectos_evaluacion.id;


--
-- Name: calendarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendarios (
    id integer NOT NULL,
    archivado boolean,
    descripcion text,
    fecha_fin timestamp with time zone,
    fecha_ini timestamp with time zone,
    semestre_id integer,
    tipo text,
    titulo text,
    anio_id integer,
    horario_id integer,
    activo boolean,
    color text,
    duracion integer,
    fecha_actualizacion timestamp with time zone,
    fecha_creacion timestamp with time zone,
    fin timestamp with time zone,
    inicio timestamp with time zone
);


--
-- Name: calendarios_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.calendarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: calendarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.calendarios_id_seq OWNED BY public.calendarios.id;


--
-- Name: capacidades_terminales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capacidades_terminales (
    id integer NOT NULL,
    unidad_didactica_id integer NOT NULL,
    descripcion text,
    sigla text
);


--
-- Name: capacidades_terminales_estudiantes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.capacidades_terminales_estudiantes (
    id integer NOT NULL,
    capacidad_terminal_id integer CONSTRAINT capacidades_terminales_estudiant_capacidad_terminal_id_not_null NOT NULL,
    matricula_id integer NOT NULL,
    promedio double precision
);


--
-- Name: capacidades_terminales_estudiantes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.capacidades_terminales_estudiantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: capacidades_terminales_estudiantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.capacidades_terminales_estudiantes_id_seq OWNED BY public.capacidades_terminales_estudiantes.id;


--
-- Name: capacidades_terminales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.capacidades_terminales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: capacidades_terminales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.capacidades_terminales_id_seq OWNED BY public.capacidades_terminales.id;


--
-- Name: carreras; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.carreras (
    id integer NOT NULL,
    act_economica_id integer,
    codigo text,
    creditos integer,
    descripcion text,
    descripcion_2 text,
    duracion text,
    nivel text,
    slug text,
    titulo text,
    titulo_comercial text,
    tipo_carrera_id integer,
    actualizado_en timestamp with time zone,
    creado_en timestamp with time zone,
    imagen_portada_url text,
    nombre text
);


--
-- Name: carreras_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.carreras_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: carreras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.carreras_id_seq OWNED BY public.carreras.id;


--
-- Name: dato_general; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dato_general (
    id integer NOT NULL,
    correo text,
    direccion text,
    facebook text,
    instagram text,
    nombre_institucion text,
    pagina_web text,
    rd text,
    ruc text,
    telefono_1 text,
    telefono_2 text,
    tiktok text,
    twitter text,
    youtube text
);


--
-- Name: dato_general_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dato_general_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dato_general_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dato_general_id_seq OWNED BY public.dato_general.id;


--
-- Name: ejes_transversales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ejes_transversales (
    id integer NOT NULL,
    descripcion text,
    nombre text
);


--
-- Name: ejes_transversales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ejes_transversales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ejes_transversales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ejes_transversales_id_seq OWNED BY public.ejes_transversales.id;


--
-- Name: especialidades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.especialidades (
    id integer NOT NULL,
    act_economica_id integer,
    descripcion text,
    descripcion_2 text,
    slug text,
    titulo text,
    titulo_comercial text,
    imagen_portada_url text
);


--
-- Name: especialidades_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.especialidades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: especialidades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.especialidades_id_seq OWNED BY public.especialidades.id;


--
-- Name: evaluaciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evaluaciones (
    id integer NOT NULL,
    actividad_id integer NOT NULL,
    indicador_capacidad_id integer NOT NULL,
    metodo_id integer,
    tecnica_id integer,
    instrumento text
);


--
-- Name: evaluaciones_estudiantes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evaluaciones_estudiantes (
    id integer NOT NULL,
    evaluacion_id integer NOT NULL,
    matricula_id integer NOT NULL,
    nota double precision
);


--
-- Name: evaluaciones_estudiantes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.evaluaciones_estudiantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: evaluaciones_estudiantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.evaluaciones_estudiantes_id_seq OWNED BY public.evaluaciones_estudiantes.id;


--
-- Name: evaluaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.evaluaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: evaluaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.evaluaciones_id_seq OWNED BY public.evaluaciones.id;


--
-- Name: evento_ocurrencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evento_ocurrencias (
    id integer NOT NULL,
    evento_id integer NOT NULL,
    grupo_id integer,
    recurrencia_id integer,
    estado text,
    fecha_actualizacion timestamp with time zone,
    fecha_creacion timestamp with time zone,
    fecha_fin timestamp with time zone,
    fecha_inicio timestamp with time zone,
    numero_ocurrencia integer,
    observacion text,
    tipo_ocurrencia text
);


--
-- Name: evento_ocurrencias_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.evento_ocurrencias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: evento_ocurrencias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.evento_ocurrencias_id_seq OWNED BY public.evento_ocurrencias.id;


--
-- Name: evento_recurrencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evento_recurrencias (
    id integer NOT NULL,
    evento_id integer NOT NULL,
    horario_id integer,
    turno_id integer,
    activo boolean,
    cantidad_ocurrencias integer,
    dia_mes integer,
    dias_semana text,
    fecha_actualizacion timestamp with time zone,
    fecha_creacion timestamp with time zone,
    fecha_fin timestamp with time zone,
    fecha_inicio timestamp with time zone,
    frecuencia text,
    intervalo integer,
    regla_especial text,
    semana_mes integer
);


--
-- Name: evento_recurrencias_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.evento_recurrencias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: evento_recurrencias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.evento_recurrencias_id_seq OWNED BY public.evento_recurrencias.id;


--
-- Name: evento_relaciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.evento_relaciones (
    id integer NOT NULL,
    evento_id integer NOT NULL,
    entidad_id integer,
    entidad_tipo text,
    fecha_actualizacion timestamp with time zone,
    fecha_creacion timestamp with time zone
);


--
-- Name: evento_relaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.evento_relaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: evento_relaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.evento_relaciones_id_seq OWNED BY public.evento_relaciones.id;


--
-- Name: eventos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.eventos (
    id integer NOT NULL,
    calendario_id integer NOT NULL,
    semestre_id integer,
    color text,
    descripcion text,
    estado text,
    fecha_actualizacion timestamp with time zone,
    fecha_creacion timestamp with time zone,
    fecha_fin timestamp with time zone,
    fecha_inicio timestamp with time zone,
    tipo_evento text,
    titulo text,
    todo_el_dia boolean,
    ubicacion text
);


--
-- Name: eventos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.eventos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: eventos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.eventos_id_seq OWNED BY public.eventos.id;


--
-- Name: familias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.familias (
    id integer NOT NULL,
    descripcion text,
    sector_id integer,
    titulo text,
    imagen_portada_url text
);


--
-- Name: familias_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.familias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: familias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.familias_id_seq OWNED BY public.familias.id;


--
-- Name: fases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fases (
    id integer NOT NULL,
    accion_id integer,
    actividad_id integer NOT NULL,
    descripcion text,
    duracion integer,
    metodologia text,
    nombre text
);


--
-- Name: fases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fases_id_seq OWNED BY public.fases.id;


--
-- Name: fases_metodos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fases_metodos (
    id integer NOT NULL,
    fase_id integer NOT NULL,
    metodo_id integer NOT NULL
);


--
-- Name: fases_metodos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fases_metodos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fases_metodos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fases_metodos_id_seq OWNED BY public.fases_metodos.id;


--
-- Name: fases_recursos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fases_recursos (
    id integer NOT NULL,
    fase_id integer NOT NULL,
    recurso_id integer NOT NULL
);


--
-- Name: fases_recursos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fases_recursos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fases_recursos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fases_recursos_id_seq OWNED BY public.fases_recursos.id;


--
-- Name: fases_tecnicas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fases_tecnicas (
    id integer NOT NULL,
    fase_id integer NOT NULL,
    tecnica_id integer NOT NULL
);


--
-- Name: fases_tecnicas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fases_tecnicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fases_tecnicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fases_tecnicas_id_seq OWNED BY public.fases_tecnicas.id;


--
-- Name: grupo_modulos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grupo_modulos (
    id integer NOT NULL,
    calendario_id integer,
    grupo_id integer NOT NULL,
    modulo_id integer NOT NULL,
    obligatorio boolean,
    orden integer
);


--
-- Name: grupo_modulos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grupo_modulos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grupo_modulos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grupo_modulos_id_seq OWNED BY public.grupo_modulos.id;


--
-- Name: grupos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grupos (
    id integer NOT NULL,
    archivado boolean,
    calendario_id integer,
    descripcion text,
    modulo_id integer,
    nombre_display text,
    personal_id integer,
    turno text,
    horario_id integer,
    paquete_id integer,
    semestre_id integer,
    turno_id integer,
    estado text,
    fecha_actualizacion timestamp with time zone,
    fecha_creacion timestamp with time zone,
    grupo_ord integer
);


--
-- Name: grupos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grupos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grupos_id_seq OWNED BY public.grupos.id;


--
-- Name: horarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.horarios (
    id integer NOT NULL,
    activo boolean,
    descripcion text,
    dias_semana text,
    fecha_actualizacion timestamp with time zone,
    fecha_creacion timestamp with time zone,
    nombre text,
    regla text,
    viernes_alterno_inicio text
);


--
-- Name: horarios_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.horarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: horarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.horarios_id_seq OWNED BY public.horarios.id;


--
-- Name: indicadores_capacidad; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicadores_capacidad (
    id integer NOT NULL,
    capacidad_terminal_id integer NOT NULL,
    descripcion text,
    sigla text
);


--
-- Name: indicadores_capacidad_estudiantes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.indicadores_capacidad_estudiantes (
    id integer NOT NULL,
    indicador_capacidad_id integer CONSTRAINT indicadores_capacidad_estudiant_indicador_capacidad_id_not_null NOT NULL,
    matricula_id integer NOT NULL,
    promedio double precision
);


--
-- Name: indicadores_capacidad_estudiantes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.indicadores_capacidad_estudiantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: indicadores_capacidad_estudiantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.indicadores_capacidad_estudiantes_id_seq OWNED BY public.indicadores_capacidad_estudiantes.id;


--
-- Name: indicadores_capacidad_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.indicadores_capacidad_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: indicadores_capacidad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.indicadores_capacidad_id_seq OWNED BY public.indicadores_capacidad.id;


--
-- Name: matricula_grupos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matricula_grupos (
    id integer NOT NULL,
    grupo_id integer NOT NULL,
    matricula_id integer NOT NULL
);


--
-- Name: matricula_grupos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matricula_grupos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matricula_grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matricula_grupos_id_seq OWNED BY public.matricula_grupos.id;


--
-- Name: matricula_paquetes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matricula_paquetes (
    id integer NOT NULL,
    matricula_id integer NOT NULL,
    paquete_id integer NOT NULL
);


--
-- Name: matricula_paquetes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matricula_paquetes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matricula_paquetes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matricula_paquetes_id_seq OWNED BY public.matricula_paquetes.id;


--
-- Name: matricula_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matricula_users (
    id integer NOT NULL,
    matricula_id integer NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: matricula_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matricula_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matricula_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matricula_users_id_seq OWNED BY public.matricula_users.id;


--
-- Name: matriculas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.matriculas (
    id integer NOT NULL,
    archivado boolean,
    fecha timestamp with time zone,
    recibo text,
    paquete_id integer,
    semestre_id integer,
    user_id integer
);


--
-- Name: matriculas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.matriculas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: matriculas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.matriculas_id_seq OWNED BY public.matriculas.id;


--
-- Name: metodos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metodos (
    id integer NOT NULL,
    descripcion text,
    nombre text
);


--
-- Name: metodos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.metodos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: metodos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.metodos_id_seq OWNED BY public.metodos.id;


--
-- Name: modulo_videos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modulo_videos (
    id integer NOT NULL,
    field text,
    modulo_id integer,
    orden integer,
    video_id integer
);


--
-- Name: modulo_videos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modulo_videos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modulo_videos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modulo_videos_id_seq OWNED BY public.modulo_videos.id;


--
-- Name: modulos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modulos (
    id integer NOT NULL,
    activo boolean,
    carrera_id integer,
    creditos integer,
    descripcion text,
    descripcion_2 text,
    horas integer,
    metas integer,
    orden integer,
    slug text,
    titulo text,
    titulo_comercial text,
    plan_id integer
);


--
-- Name: modulos_estudiantes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modulos_estudiantes (
    id integer NOT NULL,
    grupo_id integer,
    matricula_id integer NOT NULL,
    modulo_id integer NOT NULL,
    promedio double precision
);


--
-- Name: modulos_estudiantes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modulos_estudiantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modulos_estudiantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modulos_estudiantes_id_seq OWNED BY public.modulos_estudiantes.id;


--
-- Name: modulos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modulos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modulos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modulos_id_seq OWNED BY public.modulos.id;


--
-- Name: paquete_grupos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paquete_grupos (
    id integer NOT NULL,
    grupo_id integer NOT NULL,
    grupo_ord integer,
    paquete_id integer NOT NULL
);


--
-- Name: paquete_grupos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paquete_grupos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paquete_grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paquete_grupos_id_seq OWNED BY public.paquete_grupos.id;


--
-- Name: paquete_modulos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paquete_modulos (
    id integer NOT NULL,
    modulo_id integer NOT NULL,
    paquete_id integer NOT NULL,
    obligatorio boolean,
    orden integer
);


--
-- Name: paquete_modulos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paquete_modulos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paquete_modulos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paquete_modulos_id_seq OWNED BY public.paquete_modulos.id;


--
-- Name: paquetes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paquetes (
    id integer NOT NULL,
    archivado boolean,
    descripcion text,
    titulo text
);


--
-- Name: paquetes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paquetes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paquetes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paquetes_id_seq OWNED BY public.paquetes.id;


--
-- Name: personal_especialidades; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personal_especialidades (
    id integer NOT NULL,
    especialidad_id integer NOT NULL,
    orden integer,
    personal_id integer NOT NULL
);


--
-- Name: personal_especialidades_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.personal_especialidades_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: personal_especialidades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.personal_especialidades_id_seq OWNED BY public.personal_especialidades.id;


--
-- Name: personales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.personales (
    id integer NOT NULL,
    display_name text,
    memo text,
    user_id integer
);


--
-- Name: personales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.personales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: personales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.personales_id_seq OWNED BY public.personales.id;


--
-- Name: planes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.planes (
    id integer NOT NULL,
    carrera_id integer,
    periodo_vigencia_id integer,
    anio integer,
    creditos integer,
    descripcion_2 text,
    duracion text,
    genera text,
    imagen_portada_url text,
    nro text,
    periodo_caducidad text,
    plan_estudio text,
    resolucion_tipo text,
    slug text,
    titulo_comercial text
);


--
-- Name: planes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.planes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: planes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.planes_id_seq OWNED BY public.planes.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    comentarios_activos boolean DEFAULT true NOT NULL,
    contenido text,
    creado_por_uid character varying(128),
    entidad_id character varying(120),
    entidad_tipo character varying(80),
    estado character varying(40) DEFAULT 'borrador'::character varying NOT NULL,
    fecha_actualizacion timestamp with time zone,
    fecha_creacion timestamp with time zone,
    fecha_publicacion timestamp with time zone,
    imagen_portada_url text,
    resumen text,
    slug character varying(260) NOT NULL,
    tipo character varying(40) NOT NULL,
    titulo character varying(220) NOT NULL
);


--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: publicacion_videos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.publicacion_videos (
    id integer NOT NULL,
    field text,
    orden integer,
    publicacion_id integer,
    video_id integer
);


--
-- Name: publicacion_videos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.publicacion_videos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: publicacion_videos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.publicacion_videos_id_seq OWNED BY public.publicacion_videos.id;


--
-- Name: publicaciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.publicaciones (
    id integer NOT NULL,
    contenido_1 text,
    contenido_2 text,
    descripcion_corta text,
    destacado boolean,
    fecha_evento_fin timestamp with time zone,
    fecha_evento_inicio timestamp with time zone,
    fecha_publicacion timestamp with time zone,
    slug text,
    tipo text,
    titulo text,
    ubicacion text
);


--
-- Name: publicaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.publicaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: publicaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.publicaciones_id_seq OWNED BY public.publicaciones.id;


--
-- Name: recordatorios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recordatorios (
    id integer NOT NULL,
    evento_id integer,
    evento_ocurrencia_id integer,
    enviado boolean,
    fecha_actualizacion timestamp with time zone,
    fecha_creacion timestamp with time zone,
    fecha_envio timestamp with time zone,
    medio text,
    minutos_antes integer,
    tipo_recordatorio text
);


--
-- Name: recordatorios_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recordatorios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recordatorios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recordatorios_id_seq OWNED BY public.recordatorios.id;


--
-- Name: recursos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recursos (
    id integer NOT NULL,
    descripcion text,
    nombre text
);


--
-- Name: recursos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recursos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recursos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recursos_id_seq OWNED BY public.recursos.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id integer CONSTRAINT roles_id_not_null1 NOT NULL,
    scala integer,
    titulo text
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sectores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sectores (
    id integer NOT NULL,
    descripcion text,
    titulo text,
    imagen_portada_url text
);


--
-- Name: sectores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sectores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sectores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sectores_id_seq OWNED BY public.sectores.id;


--
-- Name: semestres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.semestres (
    id integer NOT NULL,
    archivado boolean,
    coordinador_1_id integer,
    coordinador_2_id integer,
    descripcion text,
    director_id integer,
    titulo text,
    anio_id integer,
    fin timestamp with time zone,
    inicio timestamp with time zone
);


--
-- Name: semestres_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.semestres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: semestres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.semestres_id_seq OWNED BY public.semestres.id;


--
-- Name: tecnicas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tecnicas (
    id integer NOT NULL,
    descripcion text,
    nombre text
);


--
-- Name: tecnicas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tecnicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tecnicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tecnicas_id_seq OWNED BY public.tecnicas.id;


--
-- Name: tipo_carreras; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tipo_carreras (
    id integer NOT NULL,
    nombre text
);


--
-- Name: tipo_carreras_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tipo_carreras_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tipo_carreras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tipo_carreras_id_seq OWNED BY public.tipo_carreras.id;


--
-- Name: turnos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.turnos (
    id integer NOT NULL,
    estado text,
    fecha_actualizacion timestamp with time zone,
    fecha_creacion timestamp with time zone,
    hora_fin timestamp with time zone,
    hora_inicio timestamp with time zone,
    nombre text
);


--
-- Name: turnos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.turnos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: turnos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.turnos_id_seq OWNED BY public.turnos.id;


--
-- Name: unidades_didacticas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unidades_didacticas (
    id integer NOT NULL,
    modulo_id integer NOT NULL,
    creditos integer,
    duracion integer,
    nombre text,
    sigla text
);


--
-- Name: unidades_didacticas_estudiantes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unidades_didacticas_estudiantes (
    id integer NOT NULL,
    matricula_id integer NOT NULL,
    unidad_didactica_id integer NOT NULL,
    promedio double precision
);


--
-- Name: unidades_didacticas_estudiantes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.unidades_didacticas_estudiantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: unidades_didacticas_estudiantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.unidades_didacticas_estudiantes_id_seq OWNED BY public.unidades_didacticas_estudiantes.id;


--
-- Name: unidades_didacticas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.unidades_didacticas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: unidades_didacticas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.unidades_didacticas_id_seq OWNED BY public.unidades_didacticas.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    apellido_materno text,
    apellido_paterno text,
    apellidos text,
    avatar text,
    blocked boolean,
    celular text,
    confirmed boolean,
    direccion text,
    distrito text,
    dni text,
    document_id text,
    email text,
    estado_civil text,
    fecha_nacimiento timestamp with time zone,
    instruccion text,
    nombre text,
    provider text,
    sexo text,
    telefono text,
    tipo_documento text,
    username text,
    rol_id integer,
    correo_institucional text,
    dni_imagen_frente_url text,
    dni_imagen_reverso_url text,
    email_creador text,
    fecha_creacion timestamp with time zone,
    fecha_modificacion timestamp with time zone,
    nacionalidad text DEFAULT 'PERUANA'::text,
    dni_imagen_frente_procesada_url text,
    dni_imagen_reverso_procesada_url text,
    fecha_vencimiento timestamp with time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: valores_institucionales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.valores_institucionales (
    id integer NOT NULL,
    descripcion text,
    nombre text
);


--
-- Name: valores_institucionales_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.valores_institucionales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: valores_institucionales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.valores_institucionales_id_seq OWNED BY public.valores_institucionales.id;


--
-- Name: videos_youtube; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.videos_youtube (
    id integer NOT NULL,
    url text
);


--
-- Name: videos_youtube_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.videos_youtube_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: videos_youtube_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.videos_youtube_id_seq OWNED BY public.videos_youtube.id;


--
-- Name: acciones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acciones ALTER COLUMN id SET DEFAULT nextval('public.acciones_id_seq'::regclass);


--
-- Name: act_economicas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_economicas ALTER COLUMN id SET DEFAULT nextval('public.act_economicas_id_seq'::regclass);


--
-- Name: actividades id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actividades ALTER COLUMN id SET DEFAULT nextval('public.actividades_id_seq'::regclass);


--
-- Name: anios id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anios ALTER COLUMN id SET DEFAULT nextval('public.anios_id_seq'::regclass);


--
-- Name: aprendizajes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aprendizajes ALTER COLUMN id SET DEFAULT nextval('public.aprendizajes_id_seq'::regclass);


--
-- Name: asistencias id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asistencias ALTER COLUMN id SET DEFAULT nextval('public.asistencias_id_seq'::regclass);


--
-- Name: aspectos_evaluacion id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aspectos_evaluacion ALTER COLUMN id SET DEFAULT nextval('public.aspectos_evaluacion_id_seq'::regclass);


--
-- Name: aspectos_evaluacion_estudiantes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aspectos_evaluacion_estudiantes ALTER COLUMN id SET DEFAULT nextval('public.aspectos_evaluacion_estudiantes_id_seq'::regclass);


--
-- Name: calendarios id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendarios ALTER COLUMN id SET DEFAULT nextval('public.calendarios_id_seq'::regclass);


--
-- Name: capacidades_terminales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capacidades_terminales ALTER COLUMN id SET DEFAULT nextval('public.capacidades_terminales_id_seq'::regclass);


--
-- Name: capacidades_terminales_estudiantes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capacidades_terminales_estudiantes ALTER COLUMN id SET DEFAULT nextval('public.capacidades_terminales_estudiantes_id_seq'::regclass);


--
-- Name: carreras id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carreras ALTER COLUMN id SET DEFAULT nextval('public.carreras_id_seq'::regclass);


--
-- Name: dato_general id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dato_general ALTER COLUMN id SET DEFAULT nextval('public.dato_general_id_seq'::regclass);


--
-- Name: ejes_transversales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ejes_transversales ALTER COLUMN id SET DEFAULT nextval('public.ejes_transversales_id_seq'::regclass);


--
-- Name: especialidades id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.especialidades ALTER COLUMN id SET DEFAULT nextval('public.especialidades_id_seq'::regclass);


--
-- Name: evaluaciones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluaciones ALTER COLUMN id SET DEFAULT nextval('public.evaluaciones_id_seq'::regclass);


--
-- Name: evaluaciones_estudiantes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluaciones_estudiantes ALTER COLUMN id SET DEFAULT nextval('public.evaluaciones_estudiantes_id_seq'::regclass);


--
-- Name: evento_ocurrencias id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_ocurrencias ALTER COLUMN id SET DEFAULT nextval('public.evento_ocurrencias_id_seq'::regclass);


--
-- Name: evento_recurrencias id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_recurrencias ALTER COLUMN id SET DEFAULT nextval('public.evento_recurrencias_id_seq'::regclass);


--
-- Name: evento_relaciones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_relaciones ALTER COLUMN id SET DEFAULT nextval('public.evento_relaciones_id_seq'::regclass);


--
-- Name: eventos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventos ALTER COLUMN id SET DEFAULT nextval('public.eventos_id_seq'::regclass);


--
-- Name: familias id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.familias ALTER COLUMN id SET DEFAULT nextval('public.familias_id_seq'::regclass);


--
-- Name: fases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases ALTER COLUMN id SET DEFAULT nextval('public.fases_id_seq'::regclass);


--
-- Name: fases_metodos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_metodos ALTER COLUMN id SET DEFAULT nextval('public.fases_metodos_id_seq'::regclass);


--
-- Name: fases_recursos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_recursos ALTER COLUMN id SET DEFAULT nextval('public.fases_recursos_id_seq'::regclass);


--
-- Name: fases_tecnicas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_tecnicas ALTER COLUMN id SET DEFAULT nextval('public.fases_tecnicas_id_seq'::regclass);


--
-- Name: grupo_modulos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupo_modulos ALTER COLUMN id SET DEFAULT nextval('public.grupo_modulos_id_seq'::regclass);


--
-- Name: grupos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupos ALTER COLUMN id SET DEFAULT nextval('public.grupos_id_seq'::regclass);


--
-- Name: horarios id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.horarios ALTER COLUMN id SET DEFAULT nextval('public.horarios_id_seq'::regclass);


--
-- Name: indicadores_capacidad id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicadores_capacidad ALTER COLUMN id SET DEFAULT nextval('public.indicadores_capacidad_id_seq'::regclass);


--
-- Name: indicadores_capacidad_estudiantes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicadores_capacidad_estudiantes ALTER COLUMN id SET DEFAULT nextval('public.indicadores_capacidad_estudiantes_id_seq'::regclass);


--
-- Name: matricula_grupos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_grupos ALTER COLUMN id SET DEFAULT nextval('public.matricula_grupos_id_seq'::regclass);


--
-- Name: matricula_paquetes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_paquetes ALTER COLUMN id SET DEFAULT nextval('public.matricula_paquetes_id_seq'::regclass);


--
-- Name: matricula_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_users ALTER COLUMN id SET DEFAULT nextval('public.matricula_users_id_seq'::regclass);


--
-- Name: matriculas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matriculas ALTER COLUMN id SET DEFAULT nextval('public.matriculas_id_seq'::regclass);


--
-- Name: metodos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metodos ALTER COLUMN id SET DEFAULT nextval('public.metodos_id_seq'::regclass);


--
-- Name: modulo_videos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulo_videos ALTER COLUMN id SET DEFAULT nextval('public.modulo_videos_id_seq'::regclass);


--
-- Name: modulos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulos ALTER COLUMN id SET DEFAULT nextval('public.modulos_id_seq'::regclass);


--
-- Name: modulos_estudiantes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulos_estudiantes ALTER COLUMN id SET DEFAULT nextval('public.modulos_estudiantes_id_seq'::regclass);


--
-- Name: paquete_grupos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paquete_grupos ALTER COLUMN id SET DEFAULT nextval('public.paquete_grupos_id_seq'::regclass);


--
-- Name: paquete_modulos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paquete_modulos ALTER COLUMN id SET DEFAULT nextval('public.paquete_modulos_id_seq'::regclass);


--
-- Name: paquetes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paquetes ALTER COLUMN id SET DEFAULT nextval('public.paquetes_id_seq'::regclass);


--
-- Name: personal_especialidades id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_especialidades ALTER COLUMN id SET DEFAULT nextval('public.personal_especialidades_id_seq'::regclass);


--
-- Name: personales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personales ALTER COLUMN id SET DEFAULT nextval('public.personales_id_seq'::regclass);


--
-- Name: planes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planes ALTER COLUMN id SET DEFAULT nextval('public.planes_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: publicacion_videos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.publicacion_videos ALTER COLUMN id SET DEFAULT nextval('public.publicacion_videos_id_seq'::regclass);


--
-- Name: publicaciones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.publicaciones ALTER COLUMN id SET DEFAULT nextval('public.publicaciones_id_seq'::regclass);


--
-- Name: recordatorios id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recordatorios ALTER COLUMN id SET DEFAULT nextval('public.recordatorios_id_seq'::regclass);


--
-- Name: recursos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recursos ALTER COLUMN id SET DEFAULT nextval('public.recursos_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sectores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectores ALTER COLUMN id SET DEFAULT nextval('public.sectores_id_seq'::regclass);


--
-- Name: semestres id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semestres ALTER COLUMN id SET DEFAULT nextval('public.semestres_id_seq'::regclass);


--
-- Name: tecnicas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tecnicas ALTER COLUMN id SET DEFAULT nextval('public.tecnicas_id_seq'::regclass);


--
-- Name: tipo_carreras id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tipo_carreras ALTER COLUMN id SET DEFAULT nextval('public.tipo_carreras_id_seq'::regclass);


--
-- Name: turnos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.turnos ALTER COLUMN id SET DEFAULT nextval('public.turnos_id_seq'::regclass);


--
-- Name: unidades_didacticas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unidades_didacticas ALTER COLUMN id SET DEFAULT nextval('public.unidades_didacticas_id_seq'::regclass);


--
-- Name: unidades_didacticas_estudiantes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unidades_didacticas_estudiantes ALTER COLUMN id SET DEFAULT nextval('public.unidades_didacticas_estudiantes_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: valores_institucionales id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.valores_institucionales ALTER COLUMN id SET DEFAULT nextval('public.valores_institucionales_id_seq'::regclass);


--
-- Name: videos_youtube id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.videos_youtube ALTER COLUMN id SET DEFAULT nextval('public.videos_youtube_id_seq'::regclass);


--
-- Data for Name: acciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acciones (id, descripcion) FROM stdin;
\.


--
-- Data for Name: act_economicas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_economicas (id, descripcion, especialidad_id, familia_id, titulo, imagen_portada_url) FROM stdin;
1	\N	1	1	OTRAS ACTIVIDADES DE SERVICIOS PERSONALES  	\N
2	\N	2	1	REPARACIÓN DE ORDENADORES Y DE EFECTOS Y ENSERES DOMÉSTICOS	\N
3	\N	2	2	SUMINISTRO DE ELECTRICIDAD, GAS, VAPOR Y AIRE ACONDICIONADO	\N
4	\N	3	3	PROGRAMACIÓN INFORMÁTICA, CONSULTORÍA DE INFORMÁTICA Y ACTIVIDADES CONEXAS	\N
5	\N	4	4	FABRICACION DE PRENDAS DE VESTIR	\N
6	\N	5	4	FABRICACION DE PRODUCTOS DE CUERO Y PRODUCTOS CONEXOS	\N
7	\N	6	5	OTRAS INDUSTRIAS MANUFACTURERA	\N
8	\N	7	6	ELABORACIÓN DE PRODUCTOS ALIMENTICIOS	\N
9	\N	8	7	PRODUCCIÓN DE MADERA Y FABRICACIÓN DE PRODUCTOS DE MADERA Y CORCHO, EXCEPTO MUEBLES, FABRICACIÓN DE ARTÍCULOS DE PAJA Y DE MATERIALES TRENSABLES	\N
\.


--
-- Data for Name: actividades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.actividades (id, aprendizaje_id, eje_transversal_id, valor_institucional_id, ambiente, bibliografia, descripcion, duracion, fecha, nombre, proposito) FROM stdin;
\.


--
-- Data for Name: anios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.anios (id, nombre, titulo) FROM stdin;
\.


--
-- Data for Name: aprendizajes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aprendizajes (id, indicador_capacidad_id, descripcion, sigla) FROM stdin;
\.


--
-- Data for Name: asistencias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.asistencias (id, evento_ocurrencia_id, matricula_id, registrado_por_id, estado_asistencia, fecha_actualizacion, fecha_creacion, observacion, registrado_at) FROM stdin;
\.


--
-- Data for Name: aspectos_evaluacion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aspectos_evaluacion (id, evaluacion_id, descripcion) FROM stdin;
\.


--
-- Data for Name: aspectos_evaluacion_estudiantes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.aspectos_evaluacion_estudiantes (id, aspecto_evaluacion_id, evaluacion_estudiante_id, puntaje) FROM stdin;
\.


--
-- Data for Name: calendarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendarios (id, archivado, descripcion, fecha_fin, fecha_ini, semestre_id, tipo, titulo, anio_id, horario_id, activo, color, duracion, fecha_actualizacion, fecha_creacion, fin, inicio) FROM stdin;
9	t	<h1 style="margin-left:40px;text-align:justify;">Titulo 1</h1><figure class="image image_resized image-style-align-left" style="width:29.86%;"><img src="http://localhost:1337/uploads/paseo_campo_ac24fc681a.png" alt="paseo-campo.png" srcset="http://localhost:1337/uploads/thumbnail_paseo_campo_ac24fc681a.png 245w, http://localhost:1337/uploads/small_paseo_campo_ac24fc681a.png 500w, http://localhost:1337/uploads/medium_paseo_campo_ac24fc681a.png 750w, http://localhost:1337/uploads/large_paseo_campo_ac24fc681a.png 1000w" sizes="100vw" width="1000"><figcaption>Family<a target="_blank" rel="noopener noreferrer" href="https://www.america.com">https://www.america.com</a></figcaption></figure><p style="margin-left:40px;text-align:justify;"><span style="font-family:Tahoma, Geneva, sans-serif;">Este es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo es un texto repetitivo.</span></p><figure class="table" style="width:66.38%;"><table class="ck-table-resized"><colgroup><col style="width:10.89%;"><col style="width:48.92%;"><col style="width:18.87%;"><col style="width:21.32%;"></colgroup><tbody><tr><td><p style="text-align:center;">Hola</p></td><td><p style="text-align:center;">Nombres y Apellidos</p></td><td><p style="text-align:center;">Edad</p></td><td><p style="text-align:center;">Sexo</p></td></tr><tr><td>1</td><td>Enrique</td><td>18</td><td>M</td></tr><tr><td>2</td><td>María</td><td>16</td><td>F</td></tr></tbody></table><figcaption>Dime que no</figcaption></figure><ol><li>Lima </li><li>peru</li><li>lito</li></ol><p>Continuamos el texto</p><ul><li>Esto es o no es</li><li>Esto Tambien</li><li>Lindo que sepas</li></ul><ul class="todo-list"><li><label class="todo-list__label"><input type="checkbox" disabled="disabled"><span class="todo-list__label__description">Hola&nbsp;</span></label></li><li><label class="todo-list__label"><input type="checkbox" disabled="disabled"><span class="todo-list__label__description">Moda</span></label></li><li><label class="todo-list__label"><input type="checkbox" disabled="disabled"><span class="todo-list__label__description">Meta</span></label></li></ul><p>&nbsp;</p><p><a target="_blank" rel="noopener noreferrer" href="https://www.america.com.pe">digo no</a>₲</p><hr><div class="page-break" style="page-break-after:always;"><span style="display:none;">&nbsp;</span></div><p>&nbsp;</p>	2025-12-23 00:00:00+00	2025-08-11 00:00:00+00	2	Academico	150 horas [lu, mi, vi@]	\N	\N	\N	\N	\N	\N	\N	\N	\N
1	f	\N	2025-07-22 00:00:00+00	2025-03-17 00:00:00+00	1	Academico	528 horas [Lu - Vi]	\N	\N	\N	\N	\N	\N	\N	\N	\N
2	f	\N	2025-07-18 00:00:00+00	2025-03-17 00:00:00+00	1	Academico	512 horas [Lu - Vi]	\N	\N	\N	\N	\N	\N	\N	\N	\N
3	f	\N	2025-05-21 00:00:00+00	2025-03-17 00:00:00+00	1	Academico	150 horas [Lu, Mi, Vi@] (1)	\N	\N	\N	\N	\N	\N	\N	\N	\N
4	f	\N	2025-05-22 00:00:00+00	2025-03-18 00:00:00+00	1	Academico	150 horas [Ma, Ju, Vi@] (1)	\N	\N	\N	\N	\N	\N	\N	\N	\N
5	f	\N	2025-07-25 00:00:00+00	2025-05-26 00:00:00+00	1	Academico	150 horas [Lu, Mi, Vi@] (2)	\N	\N	\N	\N	\N	\N	\N	\N	\N
6	f	\N	2025-07-24 00:00:00+00	2025-05-23 00:00:00+00	1	Academico	150 horas [Ma, Ju, Vi@] (2)	\N	\N	\N	\N	\N	\N	\N	\N	\N
8	f	\N	2025-07-24 00:00:00+00	2025-03-18 00:00:00+00	1	Academico	300 horas [Ma, Ju, Vi@]	\N	\N	\N	\N	\N	\N	\N	\N	\N
7	f	\N	2025-07-25 00:00:00+00	2025-03-17 00:00:00+00	1	Academico	300 horas [Lu, Mi, Vi@]	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: capacidades_terminales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.capacidades_terminales (id, unidad_didactica_id, descripcion, sigla) FROM stdin;
\.


--
-- Data for Name: capacidades_terminales_estudiantes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.capacidades_terminales_estudiantes (id, capacidad_terminal_id, matricula_id, promedio) FROM stdin;
\.


--
-- Data for Name: carreras; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.carreras (id, act_economica_id, codigo, creditos, descripcion, descripcion_2, duracion, nivel, slug, titulo, titulo_comercial, tipo_carrera_id, actualizado_en, creado_en, imagen_portada_url, nombre) FROM stdin;
2	2	\N	\N	\N	\N	1000	Auxiliar Técnico	electronica	Electrónica	Electrónica	\N	\N	\N	\N	\N
3	3	\N	\N	\N	\N	1000	Auxiliar Técnico	mantenimiento-electronico	Mantenimiento Básico de Sistemas Eléctricos	Mantenimiento Básico de Sistemas Eléctricos	\N	\N	\N	\N	\N
4	4	J2662-1-001	40	\N	\N	1056	Auxiliar Técnico	soporte-computadoras	Soporte técnico y operaciones de centros de cómputo	Soporte técnico de computadoras	\N	\N	\N	\N	\N
5	4	\N	\N	\N	\N	1000	Auxiliar Técnico	operaciones-computadoras	Operación de Computadoras	Operación de Computadoras	\N	\N	\N	\N	\N
6	5	CO714-1-003	40	\N	\N	1056	Auxiliar Técnico	corte-ensamblaje	Corte y Ensamblaje	Corte y Ensamblaje	\N	\N	\N	\N	\N
7	5	CO714-1-004	40	\N	\N	1056	Auxiliar Técnico	costura-acabados	Costura y Acabados	Costura y Acabados	\N	\N	\N	\N	\N
8	5	C0714-1-002	40	\N	\N	1056	Auxiliar Técnico	bordados-prendas	Bordado de prendas de vestir	Bordado en prendas de vestir	\N	\N	\N	\N	\N
9	5	\N	\N	\N	\N	1000	Auxiliar Técnico	confeccion-textil	Confección Textil	Confección Textil	\N	\N	\N	\N	\N
10	6	C0715-1-001	40	\N	\N	1056	Auxiliar Técnico	confeccion-calzado	Confección de calzado	Confección de calzado	\N	\N	\N	\N	\N
11	6	C0715-1-002	40	\N	\N	1056	Auxiliar Técnico	cuero-marroquineria	Confección de Artículos de Cuero y Marroquinería	Artículos de Cuero y Marroquinería	\N	\N	\N	\N	\N
12	7	\N	\N	\N	\N	1000	Auxiliar Técnico	manualidades	Manualidades	Manualidades	\N	\N	\N	\N	\N
13	8	C0610-1-001	40	\N	\N	1056	Auxiliar Técnico	panaderia-pasteleria	Panadería y Pastelería	Panadería y Pastelería	\N	\N	\N	\N	\N
14	8	\N	\N	\N	\N	1000	Auxiliar Técnico	asistente-panaderia-pasteleria	Asistencia en Pastelería y Panadería	Asistencia en Pastelería y Panadería	\N	\N	\N	\N	\N
15	9	\N	\N	\N	\N	1000	Auxiliar Técnico	mantenimiento-casas-edificios	Mantenimiento Básico de Casas y Edificios	Mantenimiento Básico de Casas y Edificios	\N	\N	\N	\N	\N
1	1	S3496-1-001	40	\N	\N	1056	Auxiliar Técnico	peluqueria-barberia	Peluquería y Barberia	Peluquería y Barberia	\N	\N	\N	\N	\N
\.


--
-- Data for Name: dato_general; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dato_general (id, correo, direccion, facebook, instagram, nombre_institucion, pagina_web, rd, ruc, telefono_1, telefono_2, tiktok, twitter, youtube) FROM stdin;
1	cetprosanmartindeporres@cetprosmp.edu.pe	Jirón Santa Clorinda 971 Urb. Palao SMP	https://www.facebook.com/cetprosanmartindeporres1/	https://www.instagram.com/cetpro.smp/	CETPRO "San Martin de Porres"	cetprosmp.edu.pe	R.D. N° 1839 - 05 - DRELM	20610635939	5341588	5346663	https://www.tiktok.com/@cetpro.sanmartindeporres	https://x.com/enkee032	https://www.youtube.com/@enriquerafaelpalominohorna3697
\.


--
-- Data for Name: ejes_transversales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ejes_transversales (id, descripcion, nombre) FROM stdin;
\.


--
-- Data for Name: especialidades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.especialidades (id, act_economica_id, descripcion, descripcion_2, slug, titulo, titulo_comercial, imagen_portada_url) FROM stdin;
1	1	\N	[{"type": "paragraph", "children": [{"text": "Solanum tuberosum, de nombre común patata (en la mayor parte de España, Filipinas y Guinea Ecuatorial) o papa (en Hispanoamérica y en las Islas Canarias)[1]​ [2]​", "type": "text"}]}]	estetica-personal	Estética Personal	Estética Personal	\N
2	2	\N	\N	electricidad-electronica	Electricidad y Electrónica	Electricidad y Electrónica	\N
4	5	\N	\N	confeccion-textil	Textil y Confección	Confección Textil	\N
5	6	\N	\N	cuero-calzado	Cuero y Calzado	Cuero y Calzado	\N
6	7	\N	\N	manualidades	Artesanía y Manualidades	Manualidades	\N
7	8	\N	\N	hosteleria-turismo	Hostelería y Turismo	Hostelería y Turismo	\N
8	9	\N	\N	carpinteria	Carpintería	Carpintería	\N
3	4	<p data-start="273" data-end="636">La especialidad de Computación del CETPRO San Martín de Porres ofrece una formación técnica integral orientada a las exigencias del mercado laboral actual. Nuestro objetivo es preparar a los estudiantes para desempeñarse con eficiencia en diversas áreas de la tecnología, brindándoles una base sólida tanto en conocimientos teóricos como en habilidades prácticas.</p><p data-start="638" data-end="1115">A lo largo de la formación, los estudiantes desarrollan competencias en cuatro módulos especializados. En el módulo de <strong data-start="757" data-end="782">Soporte Técnico de PC</strong>, aprenden a ensamblar computadoras, instalar y configurar sistemas operativos, dar mantenimiento preventivo y correctivo, y solucionar fallas comunes de hardware y software. Además, se introducen en el manejo básico de redes y en buenas prácticas de seguridad informática, habilidades muy valoradas en empresas y servicios técnicos.</p><p data-start="1117" data-end="1488">En el módulo de <strong data-start="1133" data-end="1174">Aplicativos Informáticos de Ofimática</strong>, se entrenan en el uso profesional de herramientas como Microsoft Word, Excel, PowerPoint y otras plataformas colaborativas. Se enfatiza la creación de documentos formales, hojas de cálculo con funciones automatizadas, presentaciones efectivas y el manejo de datos, esenciales en cualquier entorno administrativo.</p><p data-start="1490" data-end="1828">El módulo de <strong data-start="1503" data-end="1534">Diseño Gráfico Publicitario</strong> desarrolla la creatividad del estudiante mediante el uso de programas como Photoshop y Corel Draw. Se enseña a crear piezas gráficas para medios impresos y digitales, como logotipos, afiches, banners y contenido visual para redes sociales, aplicando principios de diseño, color y composición.</p><p data-start="1830" data-end="2157">Finalmente, el módulo de <strong data-start="1855" data-end="1884">Diseño y Programación Web</strong> introduce al estudiante en el mundo del desarrollo web. Se aprenden lenguajes como HTML, CSS y JavaScript, así como el uso de gestores de contenido, permitiendo crear sitios web modernos, responsivos y funcionales, adaptados a las necesidades actuales del entorno digital.</p>	[{"type": "paragraph", "children": [{"text": "La especialidad de Computación del CETPRO San Martín de Porres ofrece una formación técnica integral orientada a las exigencias del mercado laboral actual. Nuestro objetivo es preparar a los estudiantes para desempeñarse con eficiencia en diversas áreas de la tecnología, brindándoles una base sólida tanto en conocimientos teóricos como en habilidades prácticas.", "type": "text"}]}, {"type": "list", "format": "ordered", "children": [{"type": "list-item", "children": [{"text": "A lo largo de la formación, los estudiantes desarrollan competencias en cuatro módulos especializados. ", "type": "text"}, {"bold": true, "text": "En el módulo de Soporte Técnico de PC", "type": "text"}, {"text": ", aprenden a ensamblar computadoras, instalar y configurar sistemas operativos, dar mantenimiento preventivo y correctivo, y solucionar fallas comunes de hardware y software. Además, se introducen en el manejo básico de redes y en buenas prácticas de seguridad informática, habilidades muy valoradas en empresas y servicios técnicos.", "type": "text"}]}]}, {"type": "list", "format": "unordered", "children": [{"type": "list-item", "children": [{"text": "En el ", "type": "text"}, {"bold": true, "text": "módulo de Aplicativos Informáticos de Ofimática", "type": "text"}, {"text": ", se entrenan en el uso profesional de herramientas como Microsoft Word, Excel, PowerPoint y otras plataformas colaborativas. Se enfatiza la creación de documentos formales, hojas de cálculo con funciones automatizadas, presentaciones efectivas y el manejo de datos, esenciales en cualquier entorno administrativo.", "type": "text"}]}]}, {"type": "paragraph", "children": [{"text": "El ", "type": "text"}, {"bold": true, "text": "módulo de Diseño Gráfico Publicitario", "type": "text"}, {"text": " desarrolla la creatividad del estudiante mediante el uso de programas como Photoshop e Illustrator. Se enseña a crear piezas gráficas para medios impresos y digitales, como logotipos, afiches, banners y contenido visual para redes sociales, aplicando principios de diseño, color y composición.", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "Finalmente, el ", "type": "text"}, {"bold": true, "text": "módulo de Diseño y Programación Web", "type": "text"}, {"text": " introduce al estudiante en el mundo del desarrollo web. Se aprenden lenguajes como HTML, CSS y JavaScript, así como el uso de gestores de contenido, permitiendo crear sitios web modernos, responsivos y funcionales, adaptados a las necesidades actuales del entorno digital.", "type": "text"}]}]	computacion	Computación e Informática	Computación	\N
\.


--
-- Data for Name: evaluaciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.evaluaciones (id, actividad_id, indicador_capacidad_id, metodo_id, tecnica_id, instrumento) FROM stdin;
\.


--
-- Data for Name: evaluaciones_estudiantes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.evaluaciones_estudiantes (id, evaluacion_id, matricula_id, nota) FROM stdin;
\.


--
-- Data for Name: evento_ocurrencias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.evento_ocurrencias (id, evento_id, grupo_id, recurrencia_id, estado, fecha_actualizacion, fecha_creacion, fecha_fin, fecha_inicio, numero_ocurrencia, observacion, tipo_ocurrencia) FROM stdin;
\.


--
-- Data for Name: evento_recurrencias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.evento_recurrencias (id, evento_id, horario_id, turno_id, activo, cantidad_ocurrencias, dia_mes, dias_semana, fecha_actualizacion, fecha_creacion, fecha_fin, fecha_inicio, frecuencia, intervalo, regla_especial, semana_mes) FROM stdin;
\.


--
-- Data for Name: evento_relaciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.evento_relaciones (id, evento_id, entidad_id, entidad_tipo, fecha_actualizacion, fecha_creacion) FROM stdin;
\.


--
-- Data for Name: eventos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.eventos (id, calendario_id, semestre_id, color, descripcion, estado, fecha_actualizacion, fecha_creacion, fecha_fin, fecha_inicio, tipo_evento, titulo, todo_el_dia, ubicacion) FROM stdin;
\.


--
-- Data for Name: familias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.familias (id, descripcion, sector_id, titulo, imagen_portada_url) FROM stdin;
1	\N	1	SERVICIOS PERSONALES Y DE HOGARES	\N
2	\N	2	ENERGÍA, AGUA, Y SANEAMIENTO	\N
3	\N	3	TECNOLOGIAS DE LA INFORMACIÓN Y COMUNICACIONES – TIC’s	\N
4	\N	4	INDUSTRIA TEXTIL, CONFECCIÓN Y DEL CUERO	\N
5	\N	4	INDUSTRIA DIVERSAS	\N
6	\N	4	INDUSTRIA ALIMENTARIA BEBIDA Y TABACO	\N
7	\N	4	INDUSTRIA DE LA MADERA Y MUEBLES	\N
\.


--
-- Data for Name: fases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fases (id, accion_id, actividad_id, descripcion, duracion, metodologia, nombre) FROM stdin;
\.


--
-- Data for Name: fases_metodos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fases_metodos (id, fase_id, metodo_id) FROM stdin;
\.


--
-- Data for Name: fases_recursos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fases_recursos (id, fase_id, recurso_id) FROM stdin;
\.


--
-- Data for Name: fases_tecnicas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fases_tecnicas (id, fase_id, tecnica_id) FROM stdin;
\.


--
-- Data for Name: grupo_modulos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grupo_modulos (id, calendario_id, grupo_id, modulo_id, obligatorio, orden) FROM stdin;
\.


--
-- Data for Name: grupos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grupos (id, archivado, calendario_id, descripcion, modulo_id, nombre_display, personal_id, turno, horario_id, paquete_id, semestre_id, turno_id, estado, fecha_actualizacion, fecha_creacion, grupo_ord) FROM stdin;
21	t	9	\N	22	Bisutería  [Tarde]  lu, mi, vi@  (Marco Palomino)	1	Tarde	\N	\N	\N	\N	\N	\N	\N	\N
22	t	9	\N	24	Cerámica al Frio  [Tarde]  lu, mi, vi@  (Manuel Quispe)	3	Tarde	\N	\N	\N	\N	\N	\N	\N	\N
19	f	4	\N	22	Bisutería  [Mañana]  Ma, Ju, Vi@  (Margarita Postillon)	4	Mañana	\N	\N	\N	\N	\N	\N	\N	\N
20	f	8	\N	29	Cocina Nacional  [Noche]  Ma, Ju, Vi@  (Marco Palomino)	1	Noche	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: horarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.horarios (id, activo, descripcion, dias_semana, fecha_actualizacion, fecha_creacion, nombre, regla, viernes_alterno_inicio) FROM stdin;
\.


--
-- Data for Name: indicadores_capacidad; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicadores_capacidad (id, capacidad_terminal_id, descripcion, sigla) FROM stdin;
\.


--
-- Data for Name: indicadores_capacidad_estudiantes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.indicadores_capacidad_estudiantes (id, indicador_capacidad_id, matricula_id, promedio) FROM stdin;
\.


--
-- Data for Name: matricula_grupos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matricula_grupos (id, grupo_id, matricula_id) FROM stdin;
\.


--
-- Data for Name: matricula_paquetes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matricula_paquetes (id, matricula_id, paquete_id) FROM stdin;
\.


--
-- Data for Name: matricula_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matricula_users (id, matricula_id, user_id) FROM stdin;
\.


--
-- Data for Name: matriculas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.matriculas (id, archivado, fecha, recibo, paquete_id, semestre_id, user_id) FROM stdin;
\.


--
-- Data for Name: metodos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.metodos (id, descripcion, nombre) FROM stdin;
\.


--
-- Data for Name: modulo_videos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modulo_videos (id, field, modulo_id, orden, video_id) FROM stdin;
\.


--
-- Data for Name: modulos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modulos (id, activo, carrera_id, creditos, descripcion, descripcion_2, horas, metas, orden, slug, titulo, titulo_comercial, plan_id) FROM stdin;
23	t	12	\N	\N	\N	150	15	3	pintura-decorativa	Pintura Decorativa	Pintura Decorativa	\N
24	t	12	\N	\N	\N	150	15	4	ceramica-al-frio	Cerámica al Frio	Cerámica al Frio	\N
25	t	13	20	\N	\N	528	15	1	acondicionamiento-preparacion-panaderia-pasteleria	Acondicionamiento y Elaboración de Productos de Panadería y Pastelería	Productos Pastelería y Panadería 1	\N
26	t	13	20	\N	\N	528	15	2	decoracion-presentacion-panaderia-pasteleria	Decoración y Presentación de los Productos de Panadería y Pastelería	Productos Pastelería y Panadería 2	\N
27	t	14	\N	\N	\N	300	15	1	decoracion-tortas	Técnicas de Decoración de Tortas	Técnicas de Decoración de Tortas	\N
28	t	14	\N	\N	\N	300	15	2	buffet	Buffet	Buffet	\N
29	t	14	\N	\N	\N	300	15	3	cocina-nacional	Cocina Nacional	Cocina Nacional	\N
30	t	14	\N	\N	\N	300	15	4	tecnicas-culinarias	Técnicas Culinarias	Técnicas Culinarias	\N
31	t	15	\N	\N	\N	300	15	1	carpinteria-madera	Mantenimiento de Carpintería	Carpintería en Madera	\N
32	t	15	\N	\N	\N	300	15	2	carpinteria-melamine	Confección de Muebles en Melamina	Carpintería en Melamina	\N
1	t	1	20	\N	\N	528	15	1	corte-barba-peinado	Corte De Cabello, Barba y Peinado	Corte De Cabello, Barba y Peinado	\N
11	t	6	19	\N	\N	544	15	2	confeccion-prendas-vestir	Técnicas de Confección de Prendas de Vestir	Técnicas de Confección de Prendas de Vestir	\N
12	t	7	21	\N	\N	544	15	2	operatividad-confeccion-damas-ninios-deportiva	Técnicas de Confección de Prendas de Vestir	Oper. Maquinas, Conf. Prendas Damas, Niños, Deportivas	\N
13	t	7	19	\N	\N	528	15	2	tecnicas-acabados-prendas-vestir	Técnicas de Procesos de Acabados en Prendas de Vestir	Técnicas de Procesos de Acabados en Prendas de Vestir	\N
2	t	1	20	\N	\N	528	15	2	capilar-coloracion-ondulacion-laceado	Tratamiento Capilar, Coloración, Ondulación y Laceado 	Tratamiento Capilar, Trituración, Ondulación, Laceado	\N
3	t	2	\N	\N	\N	300	15	1	reparacion-celulares	Mantenimiento de Teléfonos Celulares	Reparacion de Celulares	\N
4	t	3	\N	\N	\N	300	15	2	intalaciones-electricas	Mantenimiento de Instalaciones Eléctricas Domiciliarias 	Instalaciones Eléctricas	\N
5	t	4	20	\N	\N	528	15	1	incidentes-operatividad-computo	Atención de Incidentes y Problemas de Operatividad en El Centro de Cómputo	Atención De Incidentes y Problemas de Operatividad en El Centro de Cómputo	\N
6	t	4	20	\N	\N	528	15	2	monitoreo-mantenimiento-computo	Monitoreo y Acciones de Mantenimiento de Centros de Cómputo	Monitoreo y Acciones de Mantenimiento de Centros de Cómputo	\N
7	t	5	\N	\N	\N	300	15	1	ofimatica	Ofimática	Ofimática	\N
8	t	5	\N	\N	\N	300	15	2	disenio-publicitario	Diseño Publicitario	Diseño Publicitario	\N
9	t	5	\N	\N	\N	300	15	3	disenio-web	Diseño Web	Diseño Web	\N
10	t	6	21	\N	\N	560	15	1	tizado-tendido-corte	Técnicas de Tizado, Tendido y Corte de Prendas de Vestir	Técnicas de Tizado, Tendido y Corte de Prendas de Vestir	\N
14	t	8	20	\N	\N	528	15	1	bordado-computarizado	Bordados Computarizado	Bordados Computarizado	\N
15	t	9	\N	\N	\N	300	15	1	tejido-maquina	Tejido a Maquina	Tejido a Maquina	\N
16	t	9	\N	\N	\N	300	15	2	tejido-mano	Tejido a Mano	Tejido a Mano	\N
18	t	11	20	\N	\N	528	15	2	ensamblado-acabado-articulos-cuero	Ensamblado y Acabado de Artículos de Cuero	Ensamblado y Acabado de Artículos de Cuero	\N
17	t	11	20	\N	\N	528	15	1	disenio-corte-articulos-cuero	Diseño y Corte de Articulos de Cuero	Patronaje y Corte de Artículos de Cuero y Marroquinería	\N
19	t	10	20	\N	\N	528	15	1	disenio-corte-calzado	Diseño y Corte de Calzado	Patronaje y Corte de Calzado	\N
20	t	10	20	\N	\N	528	15	2	aparado-armado-acabado-calzado	Aparado, Armado y Acabado de Calzado	Aparado, Armado y Acabado de Calzado	\N
21	t	12	\N	\N	\N	300	15	1	decoracion-eventos-especiales	Decoración de Eventos Especiales	Decoración de Eventos Especiales	\N
22	t	12	\N	\N	\N	150	15	2	bisuteria	Bisuterías	Bisutería	\N
\.


--
-- Data for Name: modulos_estudiantes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modulos_estudiantes (id, grupo_id, matricula_id, modulo_id, promedio) FROM stdin;
\.


--
-- Data for Name: paquete_grupos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paquete_grupos (id, grupo_id, grupo_ord, paquete_id) FROM stdin;
51	19	0	13
52	20	1	13
53	21	0	14
54	22	1	14
\.


--
-- Data for Name: paquete_modulos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paquete_modulos (id, modulo_id, paquete_id, obligatorio, orden) FROM stdin;
\.


--
-- Data for Name: paquetes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paquetes (id, archivado, descripcion, titulo) FROM stdin;
13	f	\N	Bisutería / Cocina Nacional  [Mañana]  Ma, Ju, Vi@  (Margarita Postillon)
14	t	\N	Bisutería / Cerámica al Frio  [Tarde]  lu, mi, vi@  (Marco Palomino)
\.


--
-- Data for Name: personal_especialidades; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.personal_especialidades (id, especialidad_id, orden, personal_id) FROM stdin;
10	8	1	3
12	6	2	3
13	4	0	4
9	5	1	1
14	8	2	1
\.


--
-- Data for Name: personales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.personales (id, display_name, memo, user_id) FROM stdin;
3	Manuel Quispe	<p>Mi reseña</p>	\N
1	Marco Palomino	<p>Este es su trayector</p>	\N
4	Margarita Postillon	\N	\N
\.


--
-- Data for Name: planes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.planes (id, carrera_id, periodo_vigencia_id, anio, creditos, descripcion_2, duracion, genera, imagen_portada_url, nro, periodo_caducidad, plan_estudio, resolucion_tipo, slug, titulo_comercial) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.posts (id, comentarios_activos, contenido, creado_por_uid, entidad_id, entidad_tipo, estado, fecha_actualizacion, fecha_creacion, fecha_publicacion, imagen_portada_url, resumen, slug, tipo, titulo) FROM stdin;
\.


--
-- Data for Name: publicacion_videos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.publicacion_videos (id, field, orden, publicacion_id, video_id) FROM stdin;
\.


--
-- Data for Name: publicaciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.publicaciones (id, contenido_1, contenido_2, descripcion_corta, destacado, fecha_evento_fin, fecha_evento_inicio, fecha_publicacion, slug, tipo, titulo, ubicacion) FROM stdin;
3	\N	\N	\N	t	\N	\N	2025-07-21 00:00:00+00	novenario-virgen-carmen-2025	noticia	Novenario a la Virgen del Carmen	\N
4	\N	\N	\N	t	\N	\N	2025-07-21 00:00:00+00	novenario-virgen-carmen-2025	noticia	Novenario a la Virgen del Carmen	\N
1	\N	\N	Matricula Abierta para este segundo periodo académico 2025-2 de Agosto a fines de Diciembre, separa con tiempo tu matricula, las vacantes son limitadas...	t	2025-09-10 00:00:00+00	2025-07-21 00:00:00+00	2025-07-21 00:00:00+00	matricula-2025-	comunicado	Matricula 2025-2 (Agosto - Diciembre)	CETPRO "SAN MARTIN DE PORRES"
15	\N	<h1>Contenido 2</h1>	\N	t	\N	\N	2025-08-10 00:00:00+00	publicacion	evento	Gran Inicio de Clasess Periodo Academico  2025-2	\N
14	\N	\N	Matricula Abierta para este segundo periodo académico 2025-2 de Agosto a fines de Diciembre, separa con tiempo tu matricula, las vacantes son limitadas...	t	2025-09-10 00:00:00+00	2025-07-21 00:00:00+00	2025-07-21 00:00:00+00	matricula-2025-	comunicado	Matricula 2025-2 (Agosto - Diciembre)	CETPRO "SAN MARTIN DE PORRES"
9	\N	\N	\N	t	\N	\N	2025-07-30 00:00:00+00	personal-servicio	comunicado	Se busca personal de servicio	\N
17	\N	\N	\N	t	\N	\N	2025-07-30 00:00:00+00	personal-servicio	comunicado	Se busca personal de servicio	\N
21	[{"type": "paragraph", "children": [{"text": "Queridos estudiantes, padres de familia y comunidad educativa:", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "Es para mí un honor darles la más cordial bienvenida al CETPRO San Martín de Porres, institución dedicada a la formación de técnicos emprendedores que buscan superarse y aportar al desarrollo de nuestra sociedad.", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "Nuestro compromiso es brindarles una educación de calidad, práctica y actualizada, que les permita adquirir competencias profesionales y valores que fortalezcan su desarrollo personal y laboral. Aquí encontrarán docentes comprometidos, un ambiente de respeto y oportunidades para crecer en lo académico y humano.", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "Los invito a asumir con entusiasmo este nuevo camino de aprendizaje, confiando en que cada esfuerzo los acercará a sus metas. Cuenten siempre con nuestro acompañamiento y apoyo.", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "¡Bienvenidos al CETPRO San Martín de Porres!", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "Atentamente,", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "Mg. Maria Elena Cordova Galindo", "type": "text"}]}]	\N	\N	f	\N	\N	2025-08-16 00:00:00+00	presentacion	noticia	Bienvenidos al CETPRO "San Martin de Porres"	\N
20	[{"type": "paragraph", "children": [{"text": "Queridos estudiantes, padres de familia y comunidad educativa:", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "Es para mí un honor darles la más cordial bienvenida al CETPRO San Martín de Porres, institución dedicada a la formación de técnicos emprendedores que buscan superarse y aportar al desarrollo de nuestra sociedad.", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "Nuestro compromiso es brindarles una educación de calidad, práctica y actualizada, que les permita adquirir competencias profesionales y valores que fortalezcan su desarrollo personal y laboral. Aquí encontrarán docentes comprometidos, un ambiente de respeto y oportunidades para crecer en lo académico y humano.", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "Los invito a asumir con entusiasmo este nuevo camino de aprendizaje, confiando en que cada esfuerzo los acercará a sus metas. Cuenten siempre con nuestro acompañamiento y apoyo.", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "¡Bienvenidos al CETPRO San Martín de Porres!", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "Atentamente,", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "Mg. Maria Elena Cordova Galindo", "type": "text"}]}]	\N	\N	f	\N	\N	2025-08-16 00:00:00+00	presentacion	noticia	Bienvenidos al CETPRO "San Martin de Porres"	\N
7	[{"type": "heading", "level": 3, "children": [{"text": "MISIÓN", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "El CETPRO San Martín de Porres tiene como misión formar técnicos competentes, emprendedores y con valores, capaces de responder a las necesidades del mundo laboral y social. Brindamos una educación técnico-productiva de calidad, orientada a la práctica, la innovación y el desarrollo de habilidades que permitan a nuestros estudiantes alcanzar autonomía económica y profesional. Promovemos la responsabilidad, la creatividad y el liderazgo, impulsando el espíritu emprendedor y el compromiso con la comunidad, para contribuir al progreso individual y al bienestar colectivo.", "type": "text"}]}, {"type": "heading", "level": 3, "children": [{"text": "VISIÓN", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "El CETPRO San Martín de Porres se proyecta como una institución líder en la formación técnico-productiva, reconocida por la excelencia académica y la innovación en sus programas. Aspiramos a ser un referente en la formación de técnicos emprendedores, preparados para enfrentar los retos de un mundo globalizado y tecnológico. Nuestra visión es consolidarnos como un espacio de aprendizaje integral que fomente la empleabilidad, el autoempleo y el emprendimiento sostenible, contribuyendo al desarrollo económico y social de nuestro entorno y del país.", "type": "text"}]}]	<p>Para otros usos de este término, véase Familia (desambiguación).</p><p>Escultura de Henry Moore con el título Familia. Barclay School, Stevenage, Hertfordshire, Gran Bretaña.<br>La familia es un grupo de personas formado por individuos unidos, y primordialment<img class="image_resized image-style-align-left" style="aspect-ratio:1120/643;width:38.92%;" src="http://localhost:1337/uploads/paseo_campo_ac24fc681a.png" alt="paseo-campo.png" srcset="http://localhost:1337/uploads/thumbnail_paseo_campo_ac24fc681a.png 245w,http://localhost:1337/uploads/small_paseo_campo_ac24fc681a.png 500w,http://localhost:1337/uploads/medium_paseo_campo_ac24fc681a.png 750w,http://localhost:1337/uploads/large_paseo_campo_ac24fc681a.png 1000w," sizes="100vw" width="1120" height="643">e vinculados por relaciones de filiación o de pareja.[1]​ El Diccionario de la lengua española la define, entre otras cosas, como un grupo de personas emparentadas entre sí que viven juntas, lo que lleva implícito los conceptos de parentesco y convivencia.[2]​ Según la Declaración Universal de los Derechos Humanos, es el elemento natural, universal y fundamental de la sociedad, tiene derecho a la protección de la sociedad y del Estado.[3]​</p><p>Los lazos principales que definen una familia son de dos tipos: vínculos de afinidad derivados del establecimiento de un vínculo reconocido socialmente, como el matrimonio[4]​ —que, en algunas sociedades, solo permite la unión entre dos personas mientras que en otras es posible la poligamia—, y vínculos de consanguinidad, como la filiación entre padres e hijos o los lazos que se establecen entre los hermanos que descienden de un mismo padre. También puede diferenciarse la familia según el grado de parentesco entre sus miembros.</p>	Formar técnicos competentes y emprendedores, con valores y habilidades prácticas que impulsen su empleabilidad, autoempleo y compromiso con la comunidad.	f	\N	\N	2025-01-01 00:00:00+00	mision-vision	noticia	MISION / VISION	\N
23	[{"type": "heading", "level": 3, "children": [{"text": "MISIÓN", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "El CETPRO San Martín de Porres tiene como misión formar técnicos competentes, emprendedores y con valores, capaces de responder a las necesidades del mundo laboral y social. Brindamos una educación técnico-productiva de calidad, orientada a la práctica, la innovación y el desarrollo de habilidades que permitan a nuestros estudiantes alcanzar autonomía económica y profesional. Promovemos la responsabilidad, la creatividad y el liderazgo, impulsando el espíritu emprendedor y el compromiso con la comunidad, para contribuir al progreso individual y al bienestar colectivo.", "type": "text"}]}, {"type": "heading", "level": 3, "children": [{"text": "VISIÓN", "type": "text"}]}, {"type": "paragraph", "children": [{"text": "El CETPRO San Martín de Porres se proyecta como una institución líder en la formación técnico-productiva, reconocida por la excelencia académica y la innovación en sus programas. Aspiramos a ser un referente en la formación de técnicos emprendedores, preparados para enfrentar los retos de un mundo globalizado y tecnológico. Nuestra visión es consolidarnos como un espacio de aprendizaje integral que fomente la empleabilidad, el autoempleo y el emprendimiento sostenible, contribuyendo al desarrollo económico y social de nuestro entorno y del país.", "type": "text"}]}]	<p>Para otros usos de este término, véase Familia (desambiguación).</p><p>Escultura de Henry Moore con el título Familia. Barclay School, Stevenage, Hertfordshire, Gran Bretaña.<br>La familia es un grupo de personas formado por individuos unidos, y primordialment<img class="image_resized image-style-align-left" style="aspect-ratio:1120/643;width:38.92%;" src="http://localhost:1337/uploads/paseo_campo_ac24fc681a.png" alt="paseo-campo.png" srcset="http://localhost:1337/uploads/thumbnail_paseo_campo_ac24fc681a.png 245w,http://localhost:1337/uploads/small_paseo_campo_ac24fc681a.png 500w,http://localhost:1337/uploads/medium_paseo_campo_ac24fc681a.png 750w,http://localhost:1337/uploads/large_paseo_campo_ac24fc681a.png 1000w," sizes="100vw" width="1120" height="643">e vinculados por relaciones de filiación o de pareja.[1]​ El Diccionario de la lengua española la define, entre otras cosas, como un grupo de personas emparentadas entre sí que viven juntas, lo que lleva implícito los conceptos de parentesco y convivencia.[2]​ Según la Declaración Universal de los Derechos Humanos, es el elemento natural, universal y fundamental de la sociedad, tiene derecho a la protección de la sociedad y del Estado.[3]​</p><p>Los lazos principales que definen una familia son de dos tipos: vínculos de afinidad derivados del establecimiento de un vínculo reconocido socialmente, como el matrimonio[4]​ —que, en algunas sociedades, solo permite la unión entre dos personas mientras que en otras es posible la poligamia—, y vínculos de consanguinidad, como la filiación entre padres e hijos o los lazos que se establecen entre los hermanos que descienden de un mismo padre. También puede diferenciarse la familia según el grado de parentesco entre sus miembros.</p>	Formar técnicos competentes y emprendedores, con valores y habilidades prácticas que impulsen su empleabilidad, autoempleo y compromiso con la comunidad.	f	\N	\N	2025-01-01 00:00:00+00	mision-vision	noticia	MISION / VISION	\N
\.


--
-- Data for Name: recordatorios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recordatorios (id, evento_id, evento_ocurrencia_id, enviado, fecha_actualizacion, fecha_creacion, fecha_envio, medio, minutos_antes, tipo_recordatorio) FROM stdin;
\.


--
-- Data for Name: recursos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recursos (id, descripcion, nombre) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, scala, titulo) FROM stdin;
1	0	Visitante
2	50	Ex-estudiante
3	100	Estudiante
4	200	Docente
5	300	Administrativo
6	400	Coordinador
7	500	Director
8	600	Superusuario
\.


--
-- Data for Name: sectores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sectores (id, descripcion, titulo, imagen_portada_url) FROM stdin;
1	\N	OTRAS ACTIVIDADES DE SERVICIOS	\N
2	\N	ELECTRICIDAD, GAS Y AGUA	\N
3	\N	INFORMACIÓN Y COMUNICACIONES	\N
4	\N	INDUSTRIAS MANUFACTURERAS	\N
\.


--
-- Data for Name: semestres; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.semestres (id, archivado, coordinador_1_id, coordinador_2_id, descripcion, director_id, titulo, anio_id, fin, inicio) FROM stdin;
1	f	4	1	\N	3	2025-1	\N	\N	\N
2	t	4	3	\N	1	2025-2	\N	\N	\N
\.


--
-- Data for Name: tecnicas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tecnicas (id, descripcion, nombre) FROM stdin;
\.


--
-- Data for Name: tipo_carreras; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tipo_carreras (id, nombre) FROM stdin;
\.


--
-- Data for Name: turnos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.turnos (id, estado, fecha_actualizacion, fecha_creacion, hora_fin, hora_inicio, nombre) FROM stdin;
\.


--
-- Data for Name: unidades_didacticas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unidades_didacticas (id, modulo_id, creditos, duracion, nombre, sigla) FROM stdin;
\.


--
-- Data for Name: unidades_didacticas_estudiantes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.unidades_didacticas_estudiantes (id, matricula_id, unidad_didactica_id, promedio) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, apellido_materno, apellido_paterno, apellidos, avatar, blocked, celular, confirmed, direccion, distrito, dni, document_id, email, estado_civil, fecha_nacimiento, instruccion, nombre, provider, sexo, telefono, tipo_documento, username, rol_id, correo_institucional, dni_imagen_frente_url, dni_imagen_reverso_url, email_creador, fecha_creacion, fecha_modificacion, nacionalidad, dni_imagen_frente_procesada_url, dni_imagen_reverso_procesada_url, fecha_vencimiento) FROM stdin;
13	Horna	Palomino	Palomino Horna	https://lh3.googleusercontent.com/a/ACg8ocJ5IYaBemrfQbbQ_DaLWdVljzHz6eAQcMWok2JW66je0918Z4i1=s96-c	f	941689574	\N	\N	\N	10698579	L0M2aacSJLUAHb3KTYyPl8IygeB2	enkee03@cetprosmp.edu.pe	Soltero	\N	Primaria	Enrique Rafael	\N	M	\N	DNI	Enrique Palomino	8	\N	\N	\N	\N	\N	\N	PERUANA	\N	\N	\N
\.


--
-- Data for Name: valores_institucionales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.valores_institucionales (id, descripcion, nombre) FROM stdin;
\.


--
-- Data for Name: videos_youtube; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.videos_youtube (id, url) FROM stdin;
1	https://www.youtube.com/watch?v=_6oKX-ZCP_8
2	https://www.youtube.com/watch?v=IyKoAaLrTzw
\.


--
-- Name: acciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.acciones_id_seq', 1, false);


--
-- Name: act_economicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.act_economicas_id_seq', 9, true);


--
-- Name: actividades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.actividades_id_seq', 1, false);


--
-- Name: anios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.anios_id_seq', 1, false);


--
-- Name: aprendizajes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aprendizajes_id_seq', 1, false);


--
-- Name: asistencias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.asistencias_id_seq', 1, false);


--
-- Name: aspectos_evaluacion_estudiantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aspectos_evaluacion_estudiantes_id_seq', 1, false);


--
-- Name: aspectos_evaluacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.aspectos_evaluacion_id_seq', 1, false);


--
-- Name: calendarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.calendarios_id_seq', 9, true);


--
-- Name: capacidades_terminales_estudiantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.capacidades_terminales_estudiantes_id_seq', 1, false);


--
-- Name: capacidades_terminales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.capacidades_terminales_id_seq', 1, false);


--
-- Name: carreras_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.carreras_id_seq', 15, true);


--
-- Name: dato_general_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dato_general_id_seq', 1, true);


--
-- Name: ejes_transversales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ejes_transversales_id_seq', 1, false);


--
-- Name: especialidades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.especialidades_id_seq', 8, true);


--
-- Name: evaluaciones_estudiantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.evaluaciones_estudiantes_id_seq', 1, false);


--
-- Name: evaluaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.evaluaciones_id_seq', 1, false);


--
-- Name: evento_ocurrencias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.evento_ocurrencias_id_seq', 1, false);


--
-- Name: evento_recurrencias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.evento_recurrencias_id_seq', 1, false);


--
-- Name: evento_relaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.evento_relaciones_id_seq', 1, false);


--
-- Name: eventos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.eventos_id_seq', 1, false);


--
-- Name: familias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.familias_id_seq', 7, true);


--
-- Name: fases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fases_id_seq', 1, false);


--
-- Name: fases_metodos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fases_metodos_id_seq', 1, false);


--
-- Name: fases_recursos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fases_recursos_id_seq', 1, false);


--
-- Name: fases_tecnicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fases_tecnicas_id_seq', 1, false);


--
-- Name: grupo_modulos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grupo_modulos_id_seq', 1, false);


--
-- Name: grupos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grupos_id_seq', 22, true);


--
-- Name: horarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.horarios_id_seq', 1, false);


--
-- Name: indicadores_capacidad_estudiantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.indicadores_capacidad_estudiantes_id_seq', 1, false);


--
-- Name: indicadores_capacidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.indicadores_capacidad_id_seq', 1, false);


--
-- Name: matricula_grupos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matricula_grupos_id_seq', 1, true);


--
-- Name: matricula_paquetes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matricula_paquetes_id_seq', 1, true);


--
-- Name: matricula_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matricula_users_id_seq', 2, true);


--
-- Name: matriculas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.matriculas_id_seq', 2, true);


--
-- Name: metodos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.metodos_id_seq', 1, false);


--
-- Name: modulo_videos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.modulo_videos_id_seq', 1, true);


--
-- Name: modulos_estudiantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.modulos_estudiantes_id_seq', 1, false);


--
-- Name: modulos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.modulos_id_seq', 32, true);


--
-- Name: paquete_grupos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paquete_grupos_id_seq', 54, true);


--
-- Name: paquete_modulos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paquete_modulos_id_seq', 1, false);


--
-- Name: paquetes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paquetes_id_seq', 14, true);


--
-- Name: personal_especialidades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.personal_especialidades_id_seq', 14, true);


--
-- Name: personales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.personales_id_seq', 4, true);


--
-- Name: planes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.planes_id_seq', 1, false);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.posts_id_seq', 1, false);


--
-- Name: publicacion_videos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.publicacion_videos_id_seq', 1, true);


--
-- Name: publicaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.publicaciones_id_seq', 23, true);


--
-- Name: recordatorios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recordatorios_id_seq', 1, false);


--
-- Name: recursos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recursos_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 8, true);


--
-- Name: sectores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sectores_id_seq', 4, true);


--
-- Name: semestres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.semestres_id_seq', 2, true);


--
-- Name: tecnicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tecnicas_id_seq', 1, false);


--
-- Name: tipo_carreras_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tipo_carreras_id_seq', 1, false);


--
-- Name: turnos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.turnos_id_seq', 1, false);


--
-- Name: unidades_didacticas_estudiantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.unidades_didacticas_estudiantes_id_seq', 1, false);


--
-- Name: unidades_didacticas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.unidades_didacticas_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 15, true);


--
-- Name: valores_institucionales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.valores_institucionales_id_seq', 1, false);


--
-- Name: videos_youtube_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.videos_youtube_id_seq', 2, true);


--
-- Name: acciones acciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acciones
    ADD CONSTRAINT acciones_pkey PRIMARY KEY (id);


--
-- Name: act_economicas act_economicas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_economicas
    ADD CONSTRAINT act_economicas_pkey PRIMARY KEY (id);


--
-- Name: actividades actividades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actividades
    ADD CONSTRAINT actividades_pkey PRIMARY KEY (id);


--
-- Name: anios anios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anios
    ADD CONSTRAINT anios_pkey PRIMARY KEY (id);


--
-- Name: aprendizajes aprendizajes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aprendizajes
    ADD CONSTRAINT aprendizajes_pkey PRIMARY KEY (id);


--
-- Name: asistencias asistencias_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asistencias
    ADD CONSTRAINT asistencias_pkey PRIMARY KEY (id);


--
-- Name: aspectos_evaluacion_estudiantes aspectos_evaluacion_estudiantes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aspectos_evaluacion_estudiantes
    ADD CONSTRAINT aspectos_evaluacion_estudiantes_pkey PRIMARY KEY (id);


--
-- Name: aspectos_evaluacion aspectos_evaluacion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aspectos_evaluacion
    ADD CONSTRAINT aspectos_evaluacion_pkey PRIMARY KEY (id);


--
-- Name: calendarios calendarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendarios
    ADD CONSTRAINT calendarios_pkey PRIMARY KEY (id);


--
-- Name: capacidades_terminales_estudiantes capacidades_terminales_estudiantes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capacidades_terminales_estudiantes
    ADD CONSTRAINT capacidades_terminales_estudiantes_pkey PRIMARY KEY (id);


--
-- Name: capacidades_terminales capacidades_terminales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capacidades_terminales
    ADD CONSTRAINT capacidades_terminales_pkey PRIMARY KEY (id);


--
-- Name: carreras carreras_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carreras
    ADD CONSTRAINT carreras_pkey PRIMARY KEY (id);


--
-- Name: dato_general dato_general_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dato_general
    ADD CONSTRAINT dato_general_pkey PRIMARY KEY (id);


--
-- Name: ejes_transversales ejes_transversales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ejes_transversales
    ADD CONSTRAINT ejes_transversales_pkey PRIMARY KEY (id);


--
-- Name: especialidades especialidades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.especialidades
    ADD CONSTRAINT especialidades_pkey PRIMARY KEY (id);


--
-- Name: evaluaciones_estudiantes evaluaciones_estudiantes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluaciones_estudiantes
    ADD CONSTRAINT evaluaciones_estudiantes_pkey PRIMARY KEY (id);


--
-- Name: evaluaciones evaluaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluaciones
    ADD CONSTRAINT evaluaciones_pkey PRIMARY KEY (id);


--
-- Name: evento_ocurrencias evento_ocurrencias_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_ocurrencias
    ADD CONSTRAINT evento_ocurrencias_pkey PRIMARY KEY (id);


--
-- Name: evento_recurrencias evento_recurrencias_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_recurrencias
    ADD CONSTRAINT evento_recurrencias_pkey PRIMARY KEY (id);


--
-- Name: evento_relaciones evento_relaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_relaciones
    ADD CONSTRAINT evento_relaciones_pkey PRIMARY KEY (id);


--
-- Name: eventos eventos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventos
    ADD CONSTRAINT eventos_pkey PRIMARY KEY (id);


--
-- Name: familias familias_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.familias
    ADD CONSTRAINT familias_pkey PRIMARY KEY (id);


--
-- Name: fases_metodos fases_metodos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_metodos
    ADD CONSTRAINT fases_metodos_pkey PRIMARY KEY (id);


--
-- Name: fases fases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases
    ADD CONSTRAINT fases_pkey PRIMARY KEY (id);


--
-- Name: fases_recursos fases_recursos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_recursos
    ADD CONSTRAINT fases_recursos_pkey PRIMARY KEY (id);


--
-- Name: fases_tecnicas fases_tecnicas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_tecnicas
    ADD CONSTRAINT fases_tecnicas_pkey PRIMARY KEY (id);


--
-- Name: grupo_modulos grupo_modulos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupo_modulos
    ADD CONSTRAINT grupo_modulos_pkey PRIMARY KEY (id);


--
-- Name: grupos grupos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupos
    ADD CONSTRAINT grupos_pkey PRIMARY KEY (id);


--
-- Name: horarios horarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.horarios
    ADD CONSTRAINT horarios_pkey PRIMARY KEY (id);


--
-- Name: indicadores_capacidad_estudiantes indicadores_capacidad_estudiantes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicadores_capacidad_estudiantes
    ADD CONSTRAINT indicadores_capacidad_estudiantes_pkey PRIMARY KEY (id);


--
-- Name: indicadores_capacidad indicadores_capacidad_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicadores_capacidad
    ADD CONSTRAINT indicadores_capacidad_pkey PRIMARY KEY (id);


--
-- Name: matricula_grupos matricula_grupos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_grupos
    ADD CONSTRAINT matricula_grupos_pkey PRIMARY KEY (matricula_id, grupo_id);


--
-- Name: matricula_paquetes matricula_paquetes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_paquetes
    ADD CONSTRAINT matricula_paquetes_pkey PRIMARY KEY (matricula_id, paquete_id);


--
-- Name: matricula_users matricula_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_users
    ADD CONSTRAINT matricula_users_pkey PRIMARY KEY (matricula_id, user_id);


--
-- Name: matriculas matriculas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matriculas
    ADD CONSTRAINT matriculas_pkey PRIMARY KEY (id);


--
-- Name: metodos metodos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metodos
    ADD CONSTRAINT metodos_pkey PRIMARY KEY (id);


--
-- Name: modulo_videos modulo_videos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulo_videos
    ADD CONSTRAINT modulo_videos_pkey PRIMARY KEY (id);


--
-- Name: modulos_estudiantes modulos_estudiantes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulos_estudiantes
    ADD CONSTRAINT modulos_estudiantes_pkey PRIMARY KEY (id);


--
-- Name: modulos modulos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulos
    ADD CONSTRAINT modulos_pkey PRIMARY KEY (id);


--
-- Name: paquete_grupos paquete_grupos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paquete_grupos
    ADD CONSTRAINT paquete_grupos_pkey PRIMARY KEY (paquete_id, grupo_id);


--
-- Name: paquete_modulos paquete_modulos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paquete_modulos
    ADD CONSTRAINT paquete_modulos_pkey PRIMARY KEY (id);


--
-- Name: paquetes paquetes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paquetes
    ADD CONSTRAINT paquetes_pkey PRIMARY KEY (id);


--
-- Name: personal_especialidades personal_especialidades_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_especialidades
    ADD CONSTRAINT personal_especialidades_pkey PRIMARY KEY (personal_id, especialidad_id);


--
-- Name: personales personales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personales
    ADD CONSTRAINT personales_pkey PRIMARY KEY (id);


--
-- Name: planes planes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planes
    ADD CONSTRAINT planes_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: publicacion_videos publicacion_videos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.publicacion_videos
    ADD CONSTRAINT publicacion_videos_pkey PRIMARY KEY (id);


--
-- Name: publicaciones publicaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.publicaciones
    ADD CONSTRAINT publicaciones_pkey PRIMARY KEY (id);


--
-- Name: recordatorios recordatorios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recordatorios
    ADD CONSTRAINT recordatorios_pkey PRIMARY KEY (id);


--
-- Name: recursos recursos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recursos
    ADD CONSTRAINT recursos_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey1 PRIMARY KEY (id);


--
-- Name: sectores sectores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sectores
    ADD CONSTRAINT sectores_pkey PRIMARY KEY (id);


--
-- Name: semestres semestres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semestres
    ADD CONSTRAINT semestres_pkey PRIMARY KEY (id);


--
-- Name: tecnicas tecnicas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tecnicas
    ADD CONSTRAINT tecnicas_pkey PRIMARY KEY (id);


--
-- Name: tipo_carreras tipo_carreras_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tipo_carreras
    ADD CONSTRAINT tipo_carreras_pkey PRIMARY KEY (id);


--
-- Name: turnos turnos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.turnos
    ADD CONSTRAINT turnos_pkey PRIMARY KEY (id);


--
-- Name: unidades_didacticas_estudiantes unidades_didacticas_estudiantes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unidades_didacticas_estudiantes
    ADD CONSTRAINT unidades_didacticas_estudiantes_pkey PRIMARY KEY (id);


--
-- Name: unidades_didacticas unidades_didacticas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unidades_didacticas
    ADD CONSTRAINT unidades_didacticas_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: valores_institucionales valores_institucionales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.valores_institucionales
    ADD CONSTRAINT valores_institucionales_pkey PRIMARY KEY (id);


--
-- Name: videos_youtube videos_youtube_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.videos_youtube
    ADD CONSTRAINT videos_youtube_pkey PRIMARY KEY (id);


--
-- Name: act_economicas_especialidadId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "act_economicas_especialidadId_idx" ON public.act_economicas USING btree (especialidad_id);


--
-- Name: act_economicas_familiaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "act_economicas_familiaId_idx" ON public.act_economicas USING btree (familia_id);


--
-- Name: actividades_aprendizajeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "actividades_aprendizajeId_idx" ON public.actividades USING btree (aprendizaje_id);


--
-- Name: actividades_ejeTransversalId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "actividades_ejeTransversalId_idx" ON public.actividades USING btree (eje_transversal_id);


--
-- Name: actividades_valorInstitucionalId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "actividades_valorInstitucionalId_idx" ON public.actividades USING btree (valor_institucional_id);


--
-- Name: aprendizajes_indicadorCapacidadId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "aprendizajes_indicadorCapacidadId_idx" ON public.aprendizajes USING btree (indicador_capacidad_id);


--
-- Name: asistencias_eventoOcurrenciaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "asistencias_eventoOcurrenciaId_idx" ON public.asistencias USING btree (evento_ocurrencia_id);


--
-- Name: asistencias_eventoOcurrenciaId_matriculaId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "asistencias_eventoOcurrenciaId_matriculaId_uidx" ON public.asistencias USING btree (evento_ocurrencia_id, matricula_id);


--
-- Name: asistencias_matriculaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "asistencias_matriculaId_idx" ON public.asistencias USING btree (matricula_id);


--
-- Name: asistencias_registradoPorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "asistencias_registradoPorId_idx" ON public.asistencias USING btree (registrado_por_id);


--
-- Name: aspectos_evaluacion_estudiantes_aspectoEvaluacionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "aspectos_evaluacion_estudiantes_aspectoEvaluacionId_idx" ON public.aspectos_evaluacion_estudiantes USING btree (aspecto_evaluacion_id);


--
-- Name: aspectos_evaluacion_estudiantes_evaluacionEstudianteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "aspectos_evaluacion_estudiantes_evaluacionEstudianteId_idx" ON public.aspectos_evaluacion_estudiantes USING btree (evaluacion_estudiante_id);


--
-- Name: aspectos_evaluacion_estudiantes_evaluacispectoEvaluacionId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "aspectos_evaluacion_estudiantes_evaluacispectoEvaluacionId_uidx" ON public.aspectos_evaluacion_estudiantes USING btree (evaluacion_estudiante_id, aspecto_evaluacion_id);


--
-- Name: aspectos_evaluacion_evaluacionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "aspectos_evaluacion_evaluacionId_idx" ON public.aspectos_evaluacion USING btree (evaluacion_id);


--
-- Name: calendarios_anioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "calendarios_anioId_idx" ON public.calendarios USING btree (anio_id);


--
-- Name: calendarios_horarioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "calendarios_horarioId_idx" ON public.calendarios USING btree (horario_id);


--
-- Name: calendarios_semestreId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "calendarios_semestreId_idx" ON public.calendarios USING btree (semestre_id);


--
-- Name: capacidades_terminales_estudiantes_capacidadTerminalId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "capacidades_terminales_estudiantes_capacidadTerminalId_idx" ON public.capacidades_terminales_estudiantes USING btree (capacidad_terminal_id);


--
-- Name: capacidades_terminales_estudiantes_matriapacidadTerminalId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "capacidades_terminales_estudiantes_matriapacidadTerminalId_uidx" ON public.capacidades_terminales_estudiantes USING btree (matricula_id, capacidad_terminal_id);


--
-- Name: capacidades_terminales_estudiantes_matriculaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "capacidades_terminales_estudiantes_matriculaId_idx" ON public.capacidades_terminales_estudiantes USING btree (matricula_id);


--
-- Name: capacidades_terminales_unidadDidacticaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "capacidades_terminales_unidadDidacticaId_idx" ON public.capacidades_terminales USING btree (unidad_didactica_id);


--
-- Name: carreras_actEconomicaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "carreras_actEconomicaId_idx" ON public.carreras USING btree (act_economica_id);


--
-- Name: carreras_tipoCarreraId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "carreras_tipoCarreraId_idx" ON public.carreras USING btree (tipo_carrera_id);


--
-- Name: especialidades_actEconomicaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "especialidades_actEconomicaId_idx" ON public.especialidades USING btree (act_economica_id);


--
-- Name: evaluaciones_actividadId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evaluaciones_actividadId_idx" ON public.evaluaciones USING btree (actividad_id);


--
-- Name: evaluaciones_estudiantes_evaluacionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evaluaciones_estudiantes_evaluacionId_idx" ON public.evaluaciones_estudiantes USING btree (evaluacion_id);


--
-- Name: evaluaciones_estudiantes_matriculaId_evaluacionId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "evaluaciones_estudiantes_matriculaId_evaluacionId_uidx" ON public.evaluaciones_estudiantes USING btree (matricula_id, evaluacion_id);


--
-- Name: evaluaciones_estudiantes_matriculaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evaluaciones_estudiantes_matriculaId_idx" ON public.evaluaciones_estudiantes USING btree (matricula_id);


--
-- Name: evaluaciones_indicadorCapacidadId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evaluaciones_indicadorCapacidadId_idx" ON public.evaluaciones USING btree (indicador_capacidad_id);


--
-- Name: evaluaciones_metodoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evaluaciones_metodoId_idx" ON public.evaluaciones USING btree (metodo_id);


--
-- Name: evaluaciones_tecnicaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evaluaciones_tecnicaId_idx" ON public.evaluaciones USING btree (tecnica_id);


--
-- Name: evento_ocurrencias_eventoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evento_ocurrencias_eventoId_idx" ON public.evento_ocurrencias USING btree (evento_id);


--
-- Name: evento_ocurrencias_grupoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evento_ocurrencias_grupoId_idx" ON public.evento_ocurrencias USING btree (grupo_id);


--
-- Name: evento_ocurrencias_recurrenciaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evento_ocurrencias_recurrenciaId_idx" ON public.evento_ocurrencias USING btree (recurrencia_id);


--
-- Name: evento_recurrencias_eventoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evento_recurrencias_eventoId_idx" ON public.evento_recurrencias USING btree (evento_id);


--
-- Name: evento_recurrencias_horarioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evento_recurrencias_horarioId_idx" ON public.evento_recurrencias USING btree (horario_id);


--
-- Name: evento_recurrencias_turnoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evento_recurrencias_turnoId_idx" ON public.evento_recurrencias USING btree (turno_id);


--
-- Name: evento_relaciones_eventoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "evento_relaciones_eventoId_idx" ON public.evento_relaciones USING btree (evento_id);


--
-- Name: eventos_calendarioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "eventos_calendarioId_idx" ON public.eventos USING btree (calendario_id);


--
-- Name: eventos_semestreId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "eventos_semestreId_idx" ON public.eventos USING btree (semestre_id);


--
-- Name: familias_sectorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "familias_sectorId_idx" ON public.familias USING btree (sector_id);


--
-- Name: fases_accionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "fases_accionId_idx" ON public.fases USING btree (accion_id);


--
-- Name: fases_actividadId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "fases_actividadId_idx" ON public.fases USING btree (actividad_id);


--
-- Name: fases_metodos_faseId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "fases_metodos_faseId_idx" ON public.fases_metodos USING btree (fase_id);


--
-- Name: fases_metodos_faseId_metodoId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "fases_metodos_faseId_metodoId_uidx" ON public.fases_metodos USING btree (fase_id, metodo_id);


--
-- Name: fases_metodos_metodoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "fases_metodos_metodoId_idx" ON public.fases_metodos USING btree (metodo_id);


--
-- Name: fases_recursos_faseId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "fases_recursos_faseId_idx" ON public.fases_recursos USING btree (fase_id);


--
-- Name: fases_recursos_faseId_recursoId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "fases_recursos_faseId_recursoId_uidx" ON public.fases_recursos USING btree (fase_id, recurso_id);


--
-- Name: fases_recursos_recursoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "fases_recursos_recursoId_idx" ON public.fases_recursos USING btree (recurso_id);


--
-- Name: fases_tecnicas_faseId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "fases_tecnicas_faseId_idx" ON public.fases_tecnicas USING btree (fase_id);


--
-- Name: fases_tecnicas_faseId_tecnicaId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "fases_tecnicas_faseId_tecnicaId_uidx" ON public.fases_tecnicas USING btree (fase_id, tecnica_id);


--
-- Name: fases_tecnicas_tecnicaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "fases_tecnicas_tecnicaId_idx" ON public.fases_tecnicas USING btree (tecnica_id);


--
-- Name: grupo_modulos_calendarioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grupo_modulos_calendarioId_idx" ON public.grupo_modulos USING btree (calendario_id);


--
-- Name: grupo_modulos_grupoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grupo_modulos_grupoId_idx" ON public.grupo_modulos USING btree (grupo_id);


--
-- Name: grupo_modulos_grupoId_moduloId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "grupo_modulos_grupoId_moduloId_uidx" ON public.grupo_modulos USING btree (grupo_id, modulo_id);


--
-- Name: grupo_modulos_moduloId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grupo_modulos_moduloId_idx" ON public.grupo_modulos USING btree (modulo_id);


--
-- Name: grupos_calendarioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grupos_calendarioId_idx" ON public.grupos USING btree (calendario_id);


--
-- Name: grupos_horarioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grupos_horarioId_idx" ON public.grupos USING btree (horario_id);


--
-- Name: grupos_moduloId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grupos_moduloId_idx" ON public.grupos USING btree (modulo_id);


--
-- Name: grupos_paqueteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grupos_paqueteId_idx" ON public.grupos USING btree (paquete_id);


--
-- Name: grupos_personalId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grupos_personalId_idx" ON public.grupos USING btree (personal_id);


--
-- Name: grupos_semestreId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grupos_semestreId_idx" ON public.grupos USING btree (semestre_id);


--
-- Name: grupos_turnoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "grupos_turnoId_idx" ON public.grupos USING btree (turno_id);


--
-- Name: indicadores_capacidad_capacidadTerminalId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "indicadores_capacidad_capacidadTerminalId_idx" ON public.indicadores_capacidad USING btree (capacidad_terminal_id);


--
-- Name: indicadores_capacidad_estudiantes_indicadorCapacidadId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "indicadores_capacidad_estudiantes_indicadorCapacidadId_idx" ON public.indicadores_capacidad_estudiantes USING btree (indicador_capacidad_id);


--
-- Name: indicadores_capacidad_estudiantes_matricdicadorCapacidadId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "indicadores_capacidad_estudiantes_matricdicadorCapacidadId_uidx" ON public.indicadores_capacidad_estudiantes USING btree (matricula_id, indicador_capacidad_id);


--
-- Name: indicadores_capacidad_estudiantes_matriculaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "indicadores_capacidad_estudiantes_matriculaId_idx" ON public.indicadores_capacidad_estudiantes USING btree (matricula_id);


--
-- Name: matricula_grupos_grupoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "matricula_grupos_grupoId_idx" ON public.matricula_grupos USING btree (grupo_id);


--
-- Name: matricula_grupos_matriculaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "matricula_grupos_matriculaId_idx" ON public.matricula_grupos USING btree (matricula_id);


--
-- Name: matricula_paquetes_matriculaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "matricula_paquetes_matriculaId_idx" ON public.matricula_paquetes USING btree (matricula_id);


--
-- Name: matricula_paquetes_paqueteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "matricula_paquetes_paqueteId_idx" ON public.matricula_paquetes USING btree (paquete_id);


--
-- Name: matricula_users_matriculaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "matricula_users_matriculaId_idx" ON public.matricula_users USING btree (matricula_id);


--
-- Name: matricula_users_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "matricula_users_userId_idx" ON public.matricula_users USING btree (user_id);


--
-- Name: matriculas_paqueteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "matriculas_paqueteId_idx" ON public.matriculas USING btree (paquete_id);


--
-- Name: matriculas_semestreId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "matriculas_semestreId_idx" ON public.matriculas USING btree (semestre_id);


--
-- Name: matriculas_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "matriculas_userId_idx" ON public.matriculas USING btree (user_id);


--
-- Name: modulo_videos_moduloId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "modulo_videos_moduloId_idx" ON public.modulo_videos USING btree (modulo_id);


--
-- Name: modulo_videos_videoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "modulo_videos_videoId_idx" ON public.modulo_videos USING btree (video_id);


--
-- Name: modulos_carreraId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "modulos_carreraId_idx" ON public.modulos USING btree (carrera_id);


--
-- Name: modulos_estudiantes_grupoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "modulos_estudiantes_grupoId_idx" ON public.modulos_estudiantes USING btree (grupo_id);


--
-- Name: modulos_estudiantes_matriculaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "modulos_estudiantes_matriculaId_idx" ON public.modulos_estudiantes USING btree (matricula_id);


--
-- Name: modulos_estudiantes_matriculaId_moduloId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "modulos_estudiantes_matriculaId_moduloId_uidx" ON public.modulos_estudiantes USING btree (matricula_id, modulo_id);


--
-- Name: modulos_estudiantes_moduloId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "modulos_estudiantes_moduloId_idx" ON public.modulos_estudiantes USING btree (modulo_id);


--
-- Name: modulos_planId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "modulos_planId_idx" ON public.modulos USING btree (plan_id);


--
-- Name: paquete_grupos_grupoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "paquete_grupos_grupoId_idx" ON public.paquete_grupos USING btree (grupo_id);


--
-- Name: paquete_grupos_paqueteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "paquete_grupos_paqueteId_idx" ON public.paquete_grupos USING btree (paquete_id);


--
-- Name: paquete_modulos_moduloId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "paquete_modulos_moduloId_idx" ON public.paquete_modulos USING btree (modulo_id);


--
-- Name: paquete_modulos_paqueteId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "paquete_modulos_paqueteId_idx" ON public.paquete_modulos USING btree (paquete_id);


--
-- Name: paquete_modulos_paqueteId_moduloId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "paquete_modulos_paqueteId_moduloId_uidx" ON public.paquete_modulos USING btree (paquete_id, modulo_id);


--
-- Name: personal_especialidades_especialidadId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "personal_especialidades_especialidadId_idx" ON public.personal_especialidades USING btree (especialidad_id);


--
-- Name: personal_especialidades_personalId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "personal_especialidades_personalId_idx" ON public.personal_especialidades USING btree (personal_id);


--
-- Name: personales_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "personales_userId_idx" ON public.personales USING btree (user_id);


--
-- Name: planes_carreraId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "planes_carreraId_idx" ON public.planes USING btree (carrera_id);


--
-- Name: planes_periodoVigenciaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "planes_periodoVigenciaId_idx" ON public.planes USING btree (periodo_vigencia_id);


--
-- Name: posts_slug_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX posts_slug_uidx ON public.posts USING btree (slug);


--
-- Name: posts_tipo_estado_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX posts_tipo_estado_idx ON public.posts USING btree (tipo, estado);


--
-- Name: publicacion_videos_publicacionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "publicacion_videos_publicacionId_idx" ON public.publicacion_videos USING btree (publicacion_id);


--
-- Name: publicacion_videos_videoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "publicacion_videos_videoId_idx" ON public.publicacion_videos USING btree (video_id);


--
-- Name: recordatorios_eventoId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "recordatorios_eventoId_idx" ON public.recordatorios USING btree (evento_id);


--
-- Name: recordatorios_eventoOcurrenciaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "recordatorios_eventoOcurrenciaId_idx" ON public.recordatorios USING btree (evento_ocurrencia_id);


--
-- Name: semestres_anioId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "semestres_anioId_idx" ON public.semestres USING btree (anio_id);


--
-- Name: semestres_coordinador1Id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "semestres_coordinador1Id_idx" ON public.semestres USING btree (coordinador_1_id);


--
-- Name: semestres_coordinador2Id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "semestres_coordinador2Id_idx" ON public.semestres USING btree (coordinador_2_id);


--
-- Name: semestres_directorId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "semestres_directorId_idx" ON public.semestres USING btree (director_id);


--
-- Name: unidades_didacticas_estudiantes_matricul_unidadDidacticaId_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "unidades_didacticas_estudiantes_matricul_unidadDidacticaId_uidx" ON public.unidades_didacticas_estudiantes USING btree (matricula_id, unidad_didactica_id);


--
-- Name: unidades_didacticas_estudiantes_matriculaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "unidades_didacticas_estudiantes_matriculaId_idx" ON public.unidades_didacticas_estudiantes USING btree (matricula_id);


--
-- Name: unidades_didacticas_estudiantes_unidadDidacticaId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "unidades_didacticas_estudiantes_unidadDidacticaId_idx" ON public.unidades_didacticas_estudiantes USING btree (unidad_didactica_id);


--
-- Name: unidades_didacticas_moduloId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "unidades_didacticas_moduloId_idx" ON public.unidades_didacticas USING btree (modulo_id);


--
-- Name: users_rolId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "users_rolId_idx" ON public.users USING btree (rol_id);


--
-- Name: act_economicas act_economicas_especialidad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_economicas
    ADD CONSTRAINT act_economicas_especialidad_id_fkey FOREIGN KEY (especialidad_id) REFERENCES public.especialidades(id) ON DELETE SET NULL;


--
-- Name: act_economicas act_economicas_familia_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_economicas
    ADD CONSTRAINT act_economicas_familia_id_fkey FOREIGN KEY (familia_id) REFERENCES public.familias(id) ON DELETE SET NULL;


--
-- Name: actividades actividades_aprendizaje_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actividades
    ADD CONSTRAINT actividades_aprendizaje_id_fkey FOREIGN KEY (aprendizaje_id) REFERENCES public.aprendizajes(id) ON DELETE CASCADE;


--
-- Name: actividades actividades_eje_transversal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actividades
    ADD CONSTRAINT actividades_eje_transversal_id_fkey FOREIGN KEY (eje_transversal_id) REFERENCES public.ejes_transversales(id) ON DELETE SET NULL;


--
-- Name: actividades actividades_valor_institucional_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.actividades
    ADD CONSTRAINT actividades_valor_institucional_id_fkey FOREIGN KEY (valor_institucional_id) REFERENCES public.valores_institucionales(id) ON DELETE SET NULL;


--
-- Name: aprendizajes aprendizajes_indicador_capacidad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aprendizajes
    ADD CONSTRAINT aprendizajes_indicador_capacidad_id_fkey FOREIGN KEY (indicador_capacidad_id) REFERENCES public.indicadores_capacidad(id) ON DELETE CASCADE;


--
-- Name: asistencias asistencias_evento_ocurrencia_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asistencias
    ADD CONSTRAINT asistencias_evento_ocurrencia_id_fkey FOREIGN KEY (evento_ocurrencia_id) REFERENCES public.evento_ocurrencias(id) ON DELETE CASCADE;


--
-- Name: asistencias asistencias_matricula_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asistencias
    ADD CONSTRAINT asistencias_matricula_id_fkey FOREIGN KEY (matricula_id) REFERENCES public.matriculas(id) ON DELETE CASCADE;


--
-- Name: asistencias asistencias_registrado_por_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asistencias
    ADD CONSTRAINT asistencias_registrado_por_id_fkey FOREIGN KEY (registrado_por_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: aspectos_evaluacion_estudiantes aspectos_evaluacion_estudiantes_aspecto_evaluacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aspectos_evaluacion_estudiantes
    ADD CONSTRAINT aspectos_evaluacion_estudiantes_aspecto_evaluacion_id_fkey FOREIGN KEY (aspecto_evaluacion_id) REFERENCES public.aspectos_evaluacion(id) ON DELETE CASCADE;


--
-- Name: aspectos_evaluacion_estudiantes aspectos_evaluacion_estudiantes_evaluacion_estudiante_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aspectos_evaluacion_estudiantes
    ADD CONSTRAINT aspectos_evaluacion_estudiantes_evaluacion_estudiante_id_fkey FOREIGN KEY (evaluacion_estudiante_id) REFERENCES public.evaluaciones_estudiantes(id) ON DELETE CASCADE;


--
-- Name: aspectos_evaluacion aspectos_evaluacion_evaluacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.aspectos_evaluacion
    ADD CONSTRAINT aspectos_evaluacion_evaluacion_id_fkey FOREIGN KEY (evaluacion_id) REFERENCES public.evaluaciones(id) ON DELETE CASCADE;


--
-- Name: calendarios calendarios_anio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendarios
    ADD CONSTRAINT calendarios_anio_id_fkey FOREIGN KEY (anio_id) REFERENCES public.anios(id) ON DELETE SET NULL;


--
-- Name: calendarios calendarios_horario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendarios
    ADD CONSTRAINT calendarios_horario_id_fkey FOREIGN KEY (horario_id) REFERENCES public.horarios(id) ON DELETE SET NULL;


--
-- Name: calendarios calendarios_semestre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendarios
    ADD CONSTRAINT calendarios_semestre_id_fkey FOREIGN KEY (semestre_id) REFERENCES public.semestres(id) ON DELETE SET NULL;


--
-- Name: capacidades_terminales_estudiantes capacidades_terminales_estudiantes_capacidad_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capacidades_terminales_estudiantes
    ADD CONSTRAINT capacidades_terminales_estudiantes_capacidad_terminal_id_fkey FOREIGN KEY (capacidad_terminal_id) REFERENCES public.capacidades_terminales(id) ON DELETE CASCADE;


--
-- Name: capacidades_terminales_estudiantes capacidades_terminales_estudiantes_matricula_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capacidades_terminales_estudiantes
    ADD CONSTRAINT capacidades_terminales_estudiantes_matricula_id_fkey FOREIGN KEY (matricula_id) REFERENCES public.matriculas(id) ON DELETE CASCADE;


--
-- Name: capacidades_terminales capacidades_terminales_unidad_didactica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.capacidades_terminales
    ADD CONSTRAINT capacidades_terminales_unidad_didactica_id_fkey FOREIGN KEY (unidad_didactica_id) REFERENCES public.unidades_didacticas(id) ON DELETE CASCADE;


--
-- Name: carreras carreras_act_economica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carreras
    ADD CONSTRAINT carreras_act_economica_id_fkey FOREIGN KEY (act_economica_id) REFERENCES public.act_economicas(id) ON DELETE SET NULL;


--
-- Name: carreras carreras_tipo_carrera_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.carreras
    ADD CONSTRAINT carreras_tipo_carrera_id_fkey FOREIGN KEY (tipo_carrera_id) REFERENCES public.tipo_carreras(id) ON DELETE SET NULL;


--
-- Name: especialidades especialidades_act_economica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.especialidades
    ADD CONSTRAINT especialidades_act_economica_id_fkey FOREIGN KEY (act_economica_id) REFERENCES public.act_economicas(id) ON DELETE SET NULL;


--
-- Name: evaluaciones evaluaciones_actividad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluaciones
    ADD CONSTRAINT evaluaciones_actividad_id_fkey FOREIGN KEY (actividad_id) REFERENCES public.actividades(id) ON DELETE CASCADE;


--
-- Name: evaluaciones_estudiantes evaluaciones_estudiantes_evaluacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluaciones_estudiantes
    ADD CONSTRAINT evaluaciones_estudiantes_evaluacion_id_fkey FOREIGN KEY (evaluacion_id) REFERENCES public.evaluaciones(id) ON DELETE CASCADE;


--
-- Name: evaluaciones_estudiantes evaluaciones_estudiantes_matricula_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluaciones_estudiantes
    ADD CONSTRAINT evaluaciones_estudiantes_matricula_id_fkey FOREIGN KEY (matricula_id) REFERENCES public.matriculas(id) ON DELETE CASCADE;


--
-- Name: evaluaciones evaluaciones_indicador_capacidad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluaciones
    ADD CONSTRAINT evaluaciones_indicador_capacidad_id_fkey FOREIGN KEY (indicador_capacidad_id) REFERENCES public.indicadores_capacidad(id) ON DELETE CASCADE;


--
-- Name: evaluaciones evaluaciones_metodo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluaciones
    ADD CONSTRAINT evaluaciones_metodo_id_fkey FOREIGN KEY (metodo_id) REFERENCES public.metodos(id) ON DELETE SET NULL;


--
-- Name: evaluaciones evaluaciones_tecnica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evaluaciones
    ADD CONSTRAINT evaluaciones_tecnica_id_fkey FOREIGN KEY (tecnica_id) REFERENCES public.tecnicas(id) ON DELETE SET NULL;


--
-- Name: evento_ocurrencias evento_ocurrencias_evento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_ocurrencias
    ADD CONSTRAINT evento_ocurrencias_evento_id_fkey FOREIGN KEY (evento_id) REFERENCES public.eventos(id) ON DELETE CASCADE;


--
-- Name: evento_ocurrencias evento_ocurrencias_grupo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_ocurrencias
    ADD CONSTRAINT evento_ocurrencias_grupo_id_fkey FOREIGN KEY (grupo_id) REFERENCES public.grupos(id) ON DELETE SET NULL;


--
-- Name: evento_ocurrencias evento_ocurrencias_recurrencia_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_ocurrencias
    ADD CONSTRAINT evento_ocurrencias_recurrencia_id_fkey FOREIGN KEY (recurrencia_id) REFERENCES public.evento_recurrencias(id) ON DELETE SET NULL;


--
-- Name: evento_recurrencias evento_recurrencias_evento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_recurrencias
    ADD CONSTRAINT evento_recurrencias_evento_id_fkey FOREIGN KEY (evento_id) REFERENCES public.eventos(id) ON DELETE CASCADE;


--
-- Name: evento_recurrencias evento_recurrencias_horario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_recurrencias
    ADD CONSTRAINT evento_recurrencias_horario_id_fkey FOREIGN KEY (horario_id) REFERENCES public.horarios(id) ON DELETE SET NULL;


--
-- Name: evento_recurrencias evento_recurrencias_turno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_recurrencias
    ADD CONSTRAINT evento_recurrencias_turno_id_fkey FOREIGN KEY (turno_id) REFERENCES public.turnos(id) ON DELETE SET NULL;


--
-- Name: evento_relaciones evento_relaciones_evento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.evento_relaciones
    ADD CONSTRAINT evento_relaciones_evento_id_fkey FOREIGN KEY (evento_id) REFERENCES public.eventos(id) ON DELETE CASCADE;


--
-- Name: eventos eventos_calendario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventos
    ADD CONSTRAINT eventos_calendario_id_fkey FOREIGN KEY (calendario_id) REFERENCES public.calendarios(id) ON DELETE CASCADE;


--
-- Name: eventos eventos_semestre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.eventos
    ADD CONSTRAINT eventos_semestre_id_fkey FOREIGN KEY (semestre_id) REFERENCES public.semestres(id) ON DELETE SET NULL;


--
-- Name: familias familias_sector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.familias
    ADD CONSTRAINT familias_sector_id_fkey FOREIGN KEY (sector_id) REFERENCES public.sectores(id) ON DELETE SET NULL;


--
-- Name: fases fases_accion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases
    ADD CONSTRAINT fases_accion_id_fkey FOREIGN KEY (accion_id) REFERENCES public.acciones(id) ON DELETE SET NULL;


--
-- Name: fases fases_actividad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases
    ADD CONSTRAINT fases_actividad_id_fkey FOREIGN KEY (actividad_id) REFERENCES public.actividades(id) ON DELETE CASCADE;


--
-- Name: fases_metodos fases_metodos_fase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_metodos
    ADD CONSTRAINT fases_metodos_fase_id_fkey FOREIGN KEY (fase_id) REFERENCES public.fases(id) ON DELETE CASCADE;


--
-- Name: fases_metodos fases_metodos_metodo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_metodos
    ADD CONSTRAINT fases_metodos_metodo_id_fkey FOREIGN KEY (metodo_id) REFERENCES public.metodos(id) ON DELETE CASCADE;


--
-- Name: fases_recursos fases_recursos_fase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_recursos
    ADD CONSTRAINT fases_recursos_fase_id_fkey FOREIGN KEY (fase_id) REFERENCES public.fases(id) ON DELETE CASCADE;


--
-- Name: fases_recursos fases_recursos_recurso_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_recursos
    ADD CONSTRAINT fases_recursos_recurso_id_fkey FOREIGN KEY (recurso_id) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: fases_tecnicas fases_tecnicas_fase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_tecnicas
    ADD CONSTRAINT fases_tecnicas_fase_id_fkey FOREIGN KEY (fase_id) REFERENCES public.fases(id) ON DELETE CASCADE;


--
-- Name: fases_tecnicas fases_tecnicas_tecnica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fases_tecnicas
    ADD CONSTRAINT fases_tecnicas_tecnica_id_fkey FOREIGN KEY (tecnica_id) REFERENCES public.tecnicas(id) ON DELETE CASCADE;


--
-- Name: grupo_modulos grupo_modulos_calendario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupo_modulos
    ADD CONSTRAINT grupo_modulos_calendario_id_fkey FOREIGN KEY (calendario_id) REFERENCES public.calendarios(id) ON DELETE SET NULL;


--
-- Name: grupo_modulos grupo_modulos_grupo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupo_modulos
    ADD CONSTRAINT grupo_modulos_grupo_id_fkey FOREIGN KEY (grupo_id) REFERENCES public.grupos(id) ON DELETE CASCADE;


--
-- Name: grupo_modulos grupo_modulos_modulo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupo_modulos
    ADD CONSTRAINT grupo_modulos_modulo_id_fkey FOREIGN KEY (modulo_id) REFERENCES public.modulos(id) ON DELETE CASCADE;


--
-- Name: grupos grupos_horario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupos
    ADD CONSTRAINT grupos_horario_id_fkey FOREIGN KEY (horario_id) REFERENCES public.horarios(id) ON DELETE SET NULL;


--
-- Name: grupos grupos_paquete_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupos
    ADD CONSTRAINT grupos_paquete_id_fkey FOREIGN KEY (paquete_id) REFERENCES public.paquetes(id) ON DELETE SET NULL;


--
-- Name: grupos grupos_personal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupos
    ADD CONSTRAINT grupos_personal_id_fkey FOREIGN KEY (personal_id) REFERENCES public.personales(id) ON DELETE SET NULL;


--
-- Name: grupos grupos_semestre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupos
    ADD CONSTRAINT grupos_semestre_id_fkey FOREIGN KEY (semestre_id) REFERENCES public.semestres(id) ON DELETE SET NULL;


--
-- Name: grupos grupos_turno_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grupos
    ADD CONSTRAINT grupos_turno_id_fkey FOREIGN KEY (turno_id) REFERENCES public.turnos(id) ON DELETE SET NULL;


--
-- Name: indicadores_capacidad indicadores_capacidad_capacidad_terminal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicadores_capacidad
    ADD CONSTRAINT indicadores_capacidad_capacidad_terminal_id_fkey FOREIGN KEY (capacidad_terminal_id) REFERENCES public.capacidades_terminales(id) ON DELETE CASCADE;


--
-- Name: indicadores_capacidad_estudiantes indicadores_capacidad_estudiantes_indicador_capacidad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicadores_capacidad_estudiantes
    ADD CONSTRAINT indicadores_capacidad_estudiantes_indicador_capacidad_id_fkey FOREIGN KEY (indicador_capacidad_id) REFERENCES public.indicadores_capacidad(id) ON DELETE CASCADE;


--
-- Name: indicadores_capacidad_estudiantes indicadores_capacidad_estudiantes_matricula_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.indicadores_capacidad_estudiantes
    ADD CONSTRAINT indicadores_capacidad_estudiantes_matricula_id_fkey FOREIGN KEY (matricula_id) REFERENCES public.matriculas(id) ON DELETE CASCADE;


--
-- Name: matricula_grupos matricula_grupos_grupo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_grupos
    ADD CONSTRAINT matricula_grupos_grupo_id_fkey FOREIGN KEY (grupo_id) REFERENCES public.grupos(id) ON DELETE CASCADE;


--
-- Name: matricula_grupos matricula_grupos_matricula_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_grupos
    ADD CONSTRAINT matricula_grupos_matricula_id_fkey FOREIGN KEY (matricula_id) REFERENCES public.matriculas(id) ON DELETE CASCADE;


--
-- Name: matricula_paquetes matricula_paquetes_matricula_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_paquetes
    ADD CONSTRAINT matricula_paquetes_matricula_id_fkey FOREIGN KEY (matricula_id) REFERENCES public.matriculas(id) ON DELETE CASCADE;


--
-- Name: matricula_paquetes matricula_paquetes_paquete_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_paquetes
    ADD CONSTRAINT matricula_paquetes_paquete_id_fkey FOREIGN KEY (paquete_id) REFERENCES public.paquetes(id) ON DELETE CASCADE;


--
-- Name: matricula_users matricula_users_matricula_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_users
    ADD CONSTRAINT matricula_users_matricula_id_fkey FOREIGN KEY (matricula_id) REFERENCES public.matriculas(id) ON DELETE CASCADE;


--
-- Name: matricula_users matricula_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matricula_users
    ADD CONSTRAINT matricula_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: matriculas matriculas_paquete_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matriculas
    ADD CONSTRAINT matriculas_paquete_id_fkey FOREIGN KEY (paquete_id) REFERENCES public.paquetes(id) ON DELETE SET NULL;


--
-- Name: matriculas matriculas_semestre_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matriculas
    ADD CONSTRAINT matriculas_semestre_id_fkey FOREIGN KEY (semestre_id) REFERENCES public.semestres(id) ON DELETE SET NULL;


--
-- Name: matriculas matriculas_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.matriculas
    ADD CONSTRAINT matriculas_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: modulo_videos modulo_videos_modulo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulo_videos
    ADD CONSTRAINT modulo_videos_modulo_id_fkey FOREIGN KEY (modulo_id) REFERENCES public.modulos(id) ON DELETE SET NULL;


--
-- Name: modulo_videos modulo_videos_video_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulo_videos
    ADD CONSTRAINT modulo_videos_video_id_fkey FOREIGN KEY (video_id) REFERENCES public.videos_youtube(id) ON DELETE SET NULL;


--
-- Name: modulos_estudiantes modulos_estudiantes_grupo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulos_estudiantes
    ADD CONSTRAINT modulos_estudiantes_grupo_id_fkey FOREIGN KEY (grupo_id) REFERENCES public.grupos(id) ON DELETE SET NULL;


--
-- Name: modulos_estudiantes modulos_estudiantes_matricula_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulos_estudiantes
    ADD CONSTRAINT modulos_estudiantes_matricula_id_fkey FOREIGN KEY (matricula_id) REFERENCES public.matriculas(id) ON DELETE CASCADE;


--
-- Name: modulos_estudiantes modulos_estudiantes_modulo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulos_estudiantes
    ADD CONSTRAINT modulos_estudiantes_modulo_id_fkey FOREIGN KEY (modulo_id) REFERENCES public.modulos(id) ON DELETE CASCADE;


--
-- Name: modulos modulos_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modulos
    ADD CONSTRAINT modulos_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.planes(id) ON DELETE SET NULL;


--
-- Name: paquete_grupos paquete_grupos_grupo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paquete_grupos
    ADD CONSTRAINT paquete_grupos_grupo_id_fkey FOREIGN KEY (grupo_id) REFERENCES public.grupos(id) ON DELETE CASCADE;


--
-- Name: paquete_grupos paquete_grupos_paquete_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paquete_grupos
    ADD CONSTRAINT paquete_grupos_paquete_id_fkey FOREIGN KEY (paquete_id) REFERENCES public.paquetes(id) ON DELETE CASCADE;


--
-- Name: paquete_modulos paquete_modulos_modulo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paquete_modulos
    ADD CONSTRAINT paquete_modulos_modulo_id_fkey FOREIGN KEY (modulo_id) REFERENCES public.modulos(id) ON DELETE CASCADE;


--
-- Name: paquete_modulos paquete_modulos_paquete_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paquete_modulos
    ADD CONSTRAINT paquete_modulos_paquete_id_fkey FOREIGN KEY (paquete_id) REFERENCES public.paquetes(id) ON DELETE CASCADE;


--
-- Name: personal_especialidades personal_especialidades_especialidad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_especialidades
    ADD CONSTRAINT personal_especialidades_especialidad_id_fkey FOREIGN KEY (especialidad_id) REFERENCES public.especialidades(id) ON DELETE CASCADE;


--
-- Name: personal_especialidades personal_especialidades_personal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personal_especialidades
    ADD CONSTRAINT personal_especialidades_personal_id_fkey FOREIGN KEY (personal_id) REFERENCES public.personales(id) ON DELETE CASCADE;


--
-- Name: personales personales_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.personales
    ADD CONSTRAINT personales_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: planes planes_carrera_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planes
    ADD CONSTRAINT planes_carrera_id_fkey FOREIGN KEY (carrera_id) REFERENCES public.carreras(id) ON DELETE SET NULL;


--
-- Name: planes planes_periodo_vigencia_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planes
    ADD CONSTRAINT planes_periodo_vigencia_id_fkey FOREIGN KEY (periodo_vigencia_id) REFERENCES public.semestres(id) ON DELETE SET NULL;


--
-- Name: publicacion_videos publicacion_videos_publicacion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.publicacion_videos
    ADD CONSTRAINT publicacion_videos_publicacion_id_fkey FOREIGN KEY (publicacion_id) REFERENCES public.publicaciones(id) ON DELETE SET NULL;


--
-- Name: publicacion_videos publicacion_videos_video_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.publicacion_videos
    ADD CONSTRAINT publicacion_videos_video_id_fkey FOREIGN KEY (video_id) REFERENCES public.videos_youtube(id) ON DELETE SET NULL;


--
-- Name: recordatorios recordatorios_evento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recordatorios
    ADD CONSTRAINT recordatorios_evento_id_fkey FOREIGN KEY (evento_id) REFERENCES public.eventos(id) ON DELETE SET NULL;


--
-- Name: recordatorios recordatorios_evento_ocurrencia_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recordatorios
    ADD CONSTRAINT recordatorios_evento_ocurrencia_id_fkey FOREIGN KEY (evento_ocurrencia_id) REFERENCES public.evento_ocurrencias(id) ON DELETE SET NULL;


--
-- Name: semestres semestres_anio_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semestres
    ADD CONSTRAINT semestres_anio_id_fkey FOREIGN KEY (anio_id) REFERENCES public.anios(id) ON DELETE SET NULL;


--
-- Name: semestres semestres_coordinador1_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semestres
    ADD CONSTRAINT semestres_coordinador1_id_fkey FOREIGN KEY (coordinador_1_id) REFERENCES public.personales(id) ON DELETE SET NULL;


--
-- Name: semestres semestres_coordinador2_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semestres
    ADD CONSTRAINT semestres_coordinador2_id_fkey FOREIGN KEY (coordinador_2_id) REFERENCES public.personales(id) ON DELETE SET NULL;


--
-- Name: semestres semestres_director_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.semestres
    ADD CONSTRAINT semestres_director_id_fkey FOREIGN KEY (director_id) REFERENCES public.personales(id) ON DELETE SET NULL;


--
-- Name: unidades_didacticas_estudiantes unidades_didacticas_estudiantes_matricula_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unidades_didacticas_estudiantes
    ADD CONSTRAINT unidades_didacticas_estudiantes_matricula_id_fkey FOREIGN KEY (matricula_id) REFERENCES public.matriculas(id) ON DELETE CASCADE;


--
-- Name: unidades_didacticas_estudiantes unidades_didacticas_estudiantes_unidad_didactica_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unidades_didacticas_estudiantes
    ADD CONSTRAINT unidades_didacticas_estudiantes_unidad_didactica_id_fkey FOREIGN KEY (unidad_didactica_id) REFERENCES public.unidades_didacticas(id) ON DELETE CASCADE;


--
-- Name: unidades_didacticas unidades_didacticas_modulo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unidades_didacticas
    ADD CONSTRAINT unidades_didacticas_modulo_id_fkey FOREIGN KEY (modulo_id) REFERENCES public.modulos(id) ON DELETE CASCADE;


--
-- Name: users users_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA public TO cloudsqlsuperuser;
GRANT USAGE ON SCHEMA public TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SCHEMA public TO "firebasereader_cetprosmp-db_public";


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.uuid_generate_v1() TO "firebasewriter_cetprosmp-db_public";
GRANT ALL ON FUNCTION public.uuid_generate_v1() TO "firebasereader_cetprosmp-db_public";


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.uuid_generate_v1mc() TO "firebasewriter_cetprosmp-db_public";
GRANT ALL ON FUNCTION public.uuid_generate_v1mc() TO "firebasereader_cetprosmp-db_public";


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.uuid_generate_v3(namespace uuid, name text) TO "firebasewriter_cetprosmp-db_public";
GRANT ALL ON FUNCTION public.uuid_generate_v3(namespace uuid, name text) TO "firebasereader_cetprosmp-db_public";


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.uuid_generate_v4() TO "firebasewriter_cetprosmp-db_public";
GRANT ALL ON FUNCTION public.uuid_generate_v4() TO "firebasereader_cetprosmp-db_public";


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.uuid_generate_v5(namespace uuid, name text) TO "firebasewriter_cetprosmp-db_public";
GRANT ALL ON FUNCTION public.uuid_generate_v5(namespace uuid, name text) TO "firebasereader_cetprosmp-db_public";


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.uuid_nil() TO "firebasewriter_cetprosmp-db_public";
GRANT ALL ON FUNCTION public.uuid_nil() TO "firebasereader_cetprosmp-db_public";


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.uuid_ns_dns() TO "firebasewriter_cetprosmp-db_public";
GRANT ALL ON FUNCTION public.uuid_ns_dns() TO "firebasereader_cetprosmp-db_public";


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.uuid_ns_oid() TO "firebasewriter_cetprosmp-db_public";
GRANT ALL ON FUNCTION public.uuid_ns_oid() TO "firebasereader_cetprosmp-db_public";


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.uuid_ns_url() TO "firebasewriter_cetprosmp-db_public";
GRANT ALL ON FUNCTION public.uuid_ns_url() TO "firebasereader_cetprosmp-db_public";


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: public; Owner: -
--

GRANT ALL ON FUNCTION public.uuid_ns_x500() TO "firebasewriter_cetprosmp-db_public";
GRANT ALL ON FUNCTION public.uuid_ns_x500() TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE acciones; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.acciones TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.acciones TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE acciones_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.acciones_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.acciones_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE act_economicas; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.act_economicas TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.act_economicas TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE act_economicas_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.act_economicas_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.act_economicas_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE actividades; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.actividades TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.actividades TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE actividades_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.actividades_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.actividades_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE anios; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.anios TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.anios TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE anios_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.anios_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.anios_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE aprendizajes; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.aprendizajes TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.aprendizajes TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE aprendizajes_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.aprendizajes_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.aprendizajes_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE asistencias; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.asistencias TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.asistencias TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE asistencias_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.asistencias_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.asistencias_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE aspectos_evaluacion; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.aspectos_evaluacion TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.aspectos_evaluacion TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE aspectos_evaluacion_estudiantes; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.aspectos_evaluacion_estudiantes TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.aspectos_evaluacion_estudiantes TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE aspectos_evaluacion_estudiantes_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.aspectos_evaluacion_estudiantes_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.aspectos_evaluacion_estudiantes_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE aspectos_evaluacion_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.aspectos_evaluacion_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.aspectos_evaluacion_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE calendarios; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.calendarios TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.calendarios TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE calendarios_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.calendarios_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.calendarios_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE capacidades_terminales; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.capacidades_terminales TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.capacidades_terminales TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE capacidades_terminales_estudiantes; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.capacidades_terminales_estudiantes TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.capacidades_terminales_estudiantes TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE capacidades_terminales_estudiantes_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.capacidades_terminales_estudiantes_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.capacidades_terminales_estudiantes_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE capacidades_terminales_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.capacidades_terminales_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.capacidades_terminales_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE carreras; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.carreras TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.carreras TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE carreras_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.carreras_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.carreras_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE dato_general; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.dato_general TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.dato_general TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE dato_general_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.dato_general_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.dato_general_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE ejes_transversales; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.ejes_transversales TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.ejes_transversales TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE ejes_transversales_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.ejes_transversales_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.ejes_transversales_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE especialidades; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.especialidades TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.especialidades TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE especialidades_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.especialidades_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.especialidades_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE evaluaciones; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.evaluaciones TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.evaluaciones TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE evaluaciones_estudiantes; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.evaluaciones_estudiantes TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.evaluaciones_estudiantes TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE evaluaciones_estudiantes_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.evaluaciones_estudiantes_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.evaluaciones_estudiantes_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE evaluaciones_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.evaluaciones_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.evaluaciones_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE evento_ocurrencias; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.evento_ocurrencias TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.evento_ocurrencias TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE evento_ocurrencias_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.evento_ocurrencias_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.evento_ocurrencias_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE evento_recurrencias; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.evento_recurrencias TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.evento_recurrencias TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE evento_recurrencias_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.evento_recurrencias_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.evento_recurrencias_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE evento_relaciones; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.evento_relaciones TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.evento_relaciones TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE evento_relaciones_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.evento_relaciones_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.evento_relaciones_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE eventos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.eventos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.eventos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE eventos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.eventos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.eventos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE familias; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.familias TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.familias TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE familias_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.familias_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.familias_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE fases; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.fases TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.fases TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE fases_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.fases_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.fases_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE fases_metodos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.fases_metodos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.fases_metodos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE fases_metodos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.fases_metodos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.fases_metodos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE fases_recursos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.fases_recursos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.fases_recursos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE fases_recursos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.fases_recursos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.fases_recursos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE fases_tecnicas; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.fases_tecnicas TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.fases_tecnicas TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE fases_tecnicas_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.fases_tecnicas_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.fases_tecnicas_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE grupo_modulos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.grupo_modulos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.grupo_modulos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE grupo_modulos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.grupo_modulos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.grupo_modulos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE grupos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.grupos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.grupos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE grupos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.grupos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.grupos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE horarios; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.horarios TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.horarios TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE horarios_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.horarios_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.horarios_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE indicadores_capacidad; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.indicadores_capacidad TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.indicadores_capacidad TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE indicadores_capacidad_estudiantes; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.indicadores_capacidad_estudiantes TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.indicadores_capacidad_estudiantes TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE indicadores_capacidad_estudiantes_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.indicadores_capacidad_estudiantes_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.indicadores_capacidad_estudiantes_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE indicadores_capacidad_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.indicadores_capacidad_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.indicadores_capacidad_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE matricula_grupos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.matricula_grupos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.matricula_grupos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE matricula_grupos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.matricula_grupos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.matricula_grupos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE matricula_paquetes; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.matricula_paquetes TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.matricula_paquetes TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE matricula_paquetes_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.matricula_paquetes_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.matricula_paquetes_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE matricula_users; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.matricula_users TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.matricula_users TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE matricula_users_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.matricula_users_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.matricula_users_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE matriculas; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.matriculas TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.matriculas TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE matriculas_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.matriculas_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.matriculas_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE metodos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.metodos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.metodos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE metodos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.metodos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.metodos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE modulo_videos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.modulo_videos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.modulo_videos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE modulo_videos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.modulo_videos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.modulo_videos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE modulos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.modulos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.modulos TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE modulos_estudiantes; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.modulos_estudiantes TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.modulos_estudiantes TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE modulos_estudiantes_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.modulos_estudiantes_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.modulos_estudiantes_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE modulos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.modulos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.modulos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE paquete_grupos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.paquete_grupos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.paquete_grupos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE paquete_grupos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.paquete_grupos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.paquete_grupos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE paquete_modulos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.paquete_modulos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.paquete_modulos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE paquete_modulos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.paquete_modulos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.paquete_modulos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE paquetes; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.paquetes TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.paquetes TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE paquetes_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.paquetes_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.paquetes_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE personal_especialidades; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.personal_especialidades TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.personal_especialidades TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE personal_especialidades_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.personal_especialidades_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.personal_especialidades_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE personales; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.personales TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.personales TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE personales_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.personales_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.personales_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE planes; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.planes TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.planes TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE planes_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.planes_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.planes_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE posts; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.posts TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.posts TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE posts_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.posts_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.posts_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE publicacion_videos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.publicacion_videos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.publicacion_videos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE publicacion_videos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.publicacion_videos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.publicacion_videos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE publicaciones; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.publicaciones TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.publicaciones TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE publicaciones_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.publicaciones_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.publicaciones_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE recordatorios; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.recordatorios TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.recordatorios TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE recordatorios_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.recordatorios_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.recordatorios_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE recursos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.recursos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.recursos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE recursos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.recursos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.recursos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE roles; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT ON TABLE public.roles TO "firebasereader_cetprosmp-db_public";
GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.roles TO "firebasewriter_cetprosmp-db_public";


--
-- Name: SEQUENCE roles_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.roles_id_seq TO "firebasereader_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.roles_id_seq TO "firebasewriter_cetprosmp-db_public";


--
-- Name: TABLE sectores; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.sectores TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.sectores TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE sectores_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.sectores_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.sectores_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE semestres; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.semestres TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.semestres TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE semestres_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.semestres_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.semestres_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE tecnicas; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.tecnicas TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.tecnicas TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE tecnicas_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.tecnicas_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.tecnicas_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE tipo_carreras; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.tipo_carreras TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.tipo_carreras TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE tipo_carreras_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.tipo_carreras_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.tipo_carreras_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE turnos; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.turnos TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.turnos TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE turnos_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.turnos_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.turnos_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE unidades_didacticas; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.unidades_didacticas TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.unidades_didacticas TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE unidades_didacticas_estudiantes; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.unidades_didacticas_estudiantes TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.unidades_didacticas_estudiantes TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE unidades_didacticas_estudiantes_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.unidades_didacticas_estudiantes_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.unidades_didacticas_estudiantes_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE unidades_didacticas_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.unidades_didacticas_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.unidades_didacticas_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.users TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.users TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.users_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.users_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE valores_institucionales; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.valores_institucionales TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.valores_institucionales TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE valores_institucionales_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.valores_institucionales_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.valores_institucionales_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: TABLE videos_youtube; Type: ACL; Schema: public; Owner: -
--

GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLE public.videos_youtube TO "firebasewriter_cetprosmp-db_public";
GRANT SELECT ON TABLE public.videos_youtube TO "firebasereader_cetprosmp-db_public";


--
-- Name: SEQUENCE videos_youtube_id_seq; Type: ACL; Schema: public; Owner: -
--

GRANT USAGE ON SEQUENCE public.videos_youtube_id_seq TO "firebasewriter_cetprosmp-db_public";
GRANT USAGE ON SEQUENCE public.videos_youtube_id_seq TO "firebasereader_cetprosmp-db_public";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE "firebaseowner_cetprosmp-db_public" IN SCHEMA public GRANT USAGE ON SEQUENCES TO "firebasewriter_cetprosmp-db_public";
ALTER DEFAULT PRIVILEGES FOR ROLE "firebaseowner_cetprosmp-db_public" IN SCHEMA public GRANT USAGE ON SEQUENCES TO "firebasereader_cetprosmp-db_public";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE "firebaseowner_cetprosmp-db_public" IN SCHEMA public GRANT ALL ON FUNCTIONS TO "firebasewriter_cetprosmp-db_public";
ALTER DEFAULT PRIVILEGES FOR ROLE "firebaseowner_cetprosmp-db_public" IN SCHEMA public GRANT ALL ON FUNCTIONS TO "firebasereader_cetprosmp-db_public";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE "firebaseowner_cetprosmp-db_public" IN SCHEMA public GRANT SELECT,INSERT,DELETE,TRUNCATE,UPDATE ON TABLES TO "firebasewriter_cetprosmp-db_public";
ALTER DEFAULT PRIVILEGES FOR ROLE "firebaseowner_cetprosmp-db_public" IN SCHEMA public GRANT SELECT ON TABLES TO "firebasereader_cetprosmp-db_public";


--
-- PostgreSQL database dump complete
--

\unrestrict 1imUoEKVVdPZUyrLGZlkcGZ4PhPtKysXyK6XEvsNeY0yaQ4iW1uQa98Z2e60iNi

